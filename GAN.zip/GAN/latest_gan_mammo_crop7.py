import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
from numpy import expand_dims
from numpy import zeros
from numpy import ones
from numpy.random import randn
from numpy.random import randint

from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot
import tf_slim as slim
import os
import scipy.misc
import scipy
import latest_readMammograms2
import random
import cv2
import skimage.transform
import sklearn.preprocessing
import helper
import pdb
import csv
from numpy.random import choice
import argparse
import re
from PIL import Image
                

# example of smoothing class=1 to [0.7, 1.2]
def smooth_positive_labels(y):
	return y - 0.3 + (random(y.shape) * 0.5)
 
# randomly flip some labels
def noisy_labels(y, p_flip=0.05):  # flip labels with 5% probability
	# determine the number of labels to flip
	n_select = int(p_flip * y.shape[0])
	# choose labels to flip
	flip_ix = choice([i for i in range(y.shape[0])], size=n_select)
	# invert the labels in place
	y[flip_ix] = 1 - y[flip_ix]
	return y


def model_loss(input_real, input_z, out_channel_dim, alpha=0.2, smooth_factor=0.1): 
    d_model_real, d_logits_real = discriminator(input_real, alpha=alpha)

    d_loss_real = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_real,
                                                labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))

    input_fake = generator(input_z, out_channel_dim, alpha=alpha)
    d_model_fake, d_logits_fake = discriminator(input_fake, reuse=True, alpha=alpha)
    
    d_loss_fake = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake, labels=tf.zeros_like(d_model_fake)))
    
    g_loss = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake, labels=tf.ones_like(d_model_fake)))
    return d_loss_real + d_loss_fake, g_loss

#tests.test_model_loss(model_loss)
def model_inputs(image_width, image_height, image_channels, z_dim):
    """
    Create the model inputs
    :param image_width: The input image width
    :param image_height: The input image height
    :param image_channels: The number of image channels
    :param z_dim: The dimension of Z
    :return: Tuple of (tensor of real input images, tensor of z data, learning rate)
    """
    real_input_images = tf.placeholder(tf.float32, [None, image_width, image_height, image_channels], 'real_input_images')
    input_z = tf.placeholder(tf.float32, [None, z_dim], 'input_z')
    learning_rate = tf.placeholder(tf.float32, [], 'learning_rate')
    return real_input_images, input_z, learning_rate

# summarize 
def model_summary():
    model_vars = tf.trainable_variables()
    slim.model_analyzer.analyze_vars(model_vars, print_info=True)

# Define generator network
def generator(z):
    zP = slim.fully_connected(z,4*4*512,normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,scope='g_project',weights_initializer=initializer)
    zCon = tf.reshape(zP,[-1,4,4,512])
    #zP = slim.fully_connected(z,8*8*256,normalizer_fn=slim.batch_norm, activation_fn=tf.nn.relu,scope='g_project',weights_initializer=initializer)
    #zCon = tf.reshape(zP,[-1,8,8,256])

    gen1 = slim.convolution2d_transpose(zCon,num_outputs=1024,kernel_size=[5,5], #64, 512, 1024
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv1', weights_initializer=initializer)

    gen2 = slim.convolution2d_transpose(gen1,num_outputs=512,kernel_size=[5,5], #32, 256, 512
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv2', weights_initializer=initializer)

    gen3 = slim.convolution2d_transpose(gen2,num_outputs=256,kernel_size=[5,5], #16,  128, 256
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv3', weights_initializer=initializer)
    
    gen4 = slim.convolution2d_transpose(gen3,num_outputs=128,kernel_size=[5,5], #8,  64, 128
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv4', weights_initializer=initializer)
    
    gen5 = slim.convolution2d_transpose(gen4,num_outputs=64,kernel_size=[5,5],
        stride=[1,1],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv5', weights_initializer=initializer)
    
    g_out = slim.convolution2d_transpose(gen5,num_outputs=1,kernel_size=[32, 32],
        padding="SAME",biases_initializer=None,activation_fn=tf.nn.tanh,scope='g_conv_out',
        weights_initializer=initializer)

    return g_out

# Define descriminator network
def discriminator(bottom, reuse=False):

    dis1 = slim.convolution2d(bottom,64,[5,5],stride=[2,2],padding="SAME", #16,  64
        biases_initializer=None,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv1',
        weights_initializer=initializer)

    dis2 = slim.convolution2d(dis1,128,[5,5],stride=[2,2],padding="SAME", #32,  128
        normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv2',
        weights_initializer=initializer)

    dis3 = slim.convolution2d(dis2,256,[5,5],stride=[2,2],padding="SAME", #64,  256
        normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv3',
        weights_initializer=initializer)
    
    dis4 = slim.convolution2d(dis3,512,[5,5],stride=[1,1],padding="SAME",  #32,  512
          normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv4',
          weights_initializer=initializer)
    
    dis5 = slim.convolution2d(dis4,1024,[5,5],stride=[1,1],padding="SAME", #16,  1024
          normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv5',
          weights_initializer=initializer)
   
    out=slim.flatten(dis5)
    d_out = slim.fully_connected(out,1,activation_fn=tf.nn.sigmoid,
    reuse=reuse,scope='d_conv_out', weights_initializer=initializer)
        
    return d_out, out



#######################################################################################33333
    #BEGIN Train settings and running
#########################################################################################
learning_rateG=0.00001  #1e-4  0.00025
learning_rateD=0.00004  #0.00025
betaG=0.5 #0.45
betaD=0.5 #0.45
beta2G=0.999
beta2D=0.999
epsilon=1e-08

fixed_batch_size=32
superdir='./' #'./'#
dataset='gansMIASSmall'  #Inbreast, gansMIASLarge,  gansMIASSmall, gansDDSM  
IMG_WIDTH=256 #32, 299 1024  2560  
IMG_HEIGHT=256  #32, 299  1024 3328


RESIZE_IMG_WIDTH=64 #32, 299 1024  2560  
RESIZE_IMG_HEIGHT=64 

SAVE_IMG_WIDTH=494 #52, 32, 299 1024  2560
SAVE_IMG_HEIGHT=494  #52, 32, 299  1024 3328

#MIAS(small and large) ['MS', 'CALC', 'ARCH', 'ASYM', 'NORM', 'B', 'M', 'CIRC', 'SPIC', 'MISC']
#DDSM labels ['MS', 'CALC', 'AD', 'ASY', 'N', 'B', 'M'] 
#["MS=14351", "CALC=7051", "AD=14951", "ASY=5301", 'N', 'B', 'M']
malignTypes=["AD"] #, "CALC", "AD", "ASY", "N", 'B', 'M']
iterations = 5 # 5000, Total number of iterations to use.

z_size = 100 #Size of z vector used for generator.
alpha=0.2
smooth_factor=0.1
images   = []
synth_images   = []
#history=np.zeros((iterations,iterations), dtype=np.float64)
#true_acc = np.zeros(iterations, dtype=np.float64)
#fake_acc = np.zeros(iterations, dtype=np.float64)
#tot_acc  = np.zeros(iterations, dtype=np.float64)


#images during training
number_of_images_to_show_train=9
#images already synthesis  
number_of_images_to_show_test=9

for i in range(len(malignTypes)):
    print("Loading in Mammogram data...")
    mgrams = latest_readMammograms2.readData(i, IMG_WIDTH)
    mgram_data = mgrams.data
    mgram_labels = mgrams.labels
    print("Mammogram data loaded.\n")

    # Connecting generator and discriminator networks
    tf.reset_default_graph()
    
    #This initializaer is used to initialize all the weights of the network.
    #initializer = tf.contrib.layers.variance_scaling_initializer(dtype=tf.float32) #He initializer
    initializer = tf.truncated_normal_initializer(stddev=0.02)
    #These two placeholders are used for input into the generator and discriminator, respectively.
    z_in = tf.placeholder(shape=[None,z_size],dtype=tf.float32) #Random vector
    real_in = tf.placeholder(shape=[None,RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT,1],dtype=tf.float32) #Real images
    
    # Detect hardware
    try:
      #tpu = tf.distribute.cluster_resolver.TPUClusterResolver() # TPU detection
      tpu = tf.distribute.cluster_resolver.TPUClusterResolver()
      tf.config.experimental_connect_to_cluster(tpu)
      tf.tpu.experimental.initialize_tpu_system(tpu)
      strategy = tf.distribute.experimental.TPUStrategy(tpu)
      #print('Running on TPU ', tpu.cluster_spec().as_dict()['worker'])  
    except ValueError: # If TPU not found
      strategy = tf.distribute.get_strategy() # Default strategy that works on CPU and single GPU
      #strategy = tf.distribute.MirroredStrategy() # for GPU or multi-GPU machines
      #strategy = tf.distribute.experimental.MultiWorkerMirroredStrategy() # for clusters of multi-GPU machines
      #print('Running on CPU or GPU ')  
    
    #print("Number of accelerators: ", strategy.num_replicas_in_sync)
    
    with strategy.scope():
        Gz = generator(z_in) #Generates images from random z vectors
        Dx, d_model_real = discriminator(real_in) #Produces probabilities for real images
        Dg, d_model_fake = discriminator(Gz,reuse=True) #Produces probabilities for generator images

        #d_loss_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=Dx,labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))
        #d_loss_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=Dg, labels=tf.zeros_like(d_model_fake)))
        #g_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=Dg, labels=tf.ones_like(d_model_fake)))
        
        
        # Finally, the generator losses are using `d_logits_fake`, the fake image logits. But, now the labels are all ones. The generator is trying to fool the discriminator, so it wants to discriminator to output ones for fake images.
        d_loss_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_model_real,labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))
        d_loss_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_model_fake, labels=tf.zeros_like(d_model_fake)))
        d_loss = d_loss_real + d_loss_fake
        g_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_model_fake, labels=tf.ones_like(d_model_fake)))
        
        #These functions together define the optimization objective of the GAN.
        #d_loss = -tf.reduce_mean(tf.log(Dx) + tf.log(1.-Dg)) #This optimizes the discriminator.
        #g_loss = -tf.reduce_mean(tf.log(Dg)) #This optimizes the generator.
        
        # Compute the discriminator accuracy on real data, fake data, and total:
        accuracy_real  = tf.reduce_mean(tf.cast(tf.equal(tf.round(Dx), tf.ones_like(Dx)), tf.float32))
        accuracy_fake  = tf.reduce_mean(tf.cast(tf.equal(tf.round(Dg), tf.zeros_like(Dg)), tf.float32))
        total_accuracy = 0.5*(accuracy_fake +  accuracy_real)
        
        tvars = tf.trainable_variables()
        #The below code is responsible for applying gradient descent to update the GAN.
        g_vars = [var for var in tvars if var.name.startswith('g_conv')]
        d_vars = [var for var in tvars if var.name.startswith('d_conv')]
        trainerD = tf.train.AdamOptimizer(learning_rate=learning_rateD,beta1=betaD, beta2=beta2D, epsilon=epsilon).minimize(d_loss, var_list=d_vars)
        trainerG = tf.train.AdamOptimizer(learning_rate=learning_rateG,beta1=betaG, beta2=beta2G, epsilon=epsilon).minimize(g_loss, var_list=g_vars)
    
        '''
        #d_grads1 = tf.distribute.get_replica_context().all_reduce('sum', d_grads1)
        replica_context = tf.distribute.get_replica_context()  # for strategy
        assert tf.distribute.get_replica_context() is None
        update_D = trainerD1.apply_gradients(zip(d_grads1,tvars[9:]))
        update_G = trainerG._distributed_apply(g_grads)
        
        
        d_grads = trainerD.compute_gradients(d_loss,g_vars) #Only update the weights for the discriminator network.
        g_grads = trainerG.compute_gradients(g_loss,d_vars) #Only update the weights for the generator network.
        update_D = trainerD.apply_gradients(d_grads)
        update_G = trainerG.apply_gradients(g_grads)
        '''
        
    # Start training loop
    batch_size =0  # Size of image batch to apply at each iteration of categories of abnormalities.
    if (len(mgram_data) < fixed_batch_size):
        batch_size =len(mgram_data)
    else:
        batch_size =fixed_batch_size
    
    steps=len(mgram_data)//batch_size
   
    #"N",  "B", "AD", "ASY", "MS", "CALC"
    #https://colab.research.google.com/notebooks/io.ipynb#scrollTo=XDg9OBaYqRMd
    # Which condition to use: N = normal, B = benign, M = malignant, AD=architectural distortion, ASY=asymetry, MS=mass, CALC=calcification
    cond =malignTypes[i] #'MS' 
    
    if cond == "N" or cond == "NORM": # 'NORM',
        cond='N'
    elif cond == "AD" or cond == "ARCH": #'ARCH'
        cond='AD'
    elif cond == "ASY" or cond == "ASYM": #'ASYM', 'NORM',
        cond='ASY'
    else:
        cond=cond
    
    #superdir='./'
    synth_sample_directory = superdir+'figs_cancer_synth/'+cond #Directory to save sample images from generator in.
    model_directory2 = superdir+'models_cancer' #Directory to load trained model from.
    sample_directory = superdir+'figs_cancer2/'+dataset+'/'+cond # Directory to save sample images from generator in.
    model_directory = superdir+'models_cancer2/'+dataset+'/'+cond+'/' # Directory to save trained model to.
      
    
    saver = tf.train.Saver(max_to_keep=3)
    with tf.Session(config=tf.ConfigProto(log_device_placement=True)) as sess:
        '''        
        parser = argparse.ArgumentParser()
        parser.add_argument('checkpoint')#
        args = parser.parse_args()
        http://www.da.inf.ethz.ch/teaching/2018/DeepLearning/material/mnist-gan.py
        '''
        number_of_epoch_to_checkpoint=50
        start_epoch = 50000
        start_step = 0
        checkpoint='checkpointi'
        num_checkpoint=50000
        if checkpoint=='checkpoint':
            #ckpt = tf.train.get_checkpoint_state(model_directory) latest_checkpoint 4901, 1676
            #ckpt = tf.train.import_meta_graph(model_directory+'model-'+str(num_checkpoint)+'.cptk.meta')
            ckpt2 =tf.train.latest_checkpoint(model_directory+'/')
            print(ckpt2)
            saver.restore(sess,ckpt2)  #ckpt2.model_checkpoint_path
            found_num = re.search(r'\d+', checkpoint)
            if num_checkpoint:
                checkpoint_id = int(num_checkpoint)  #int(found_num.group(0))
                #start_epoch = checkpoint_id // iterations
                start_epoch = checkpoint_id % iterations
                print('Found latest checkpoint of '+str(start_epoch)+' starting from '+str(start_step))
        
        if num_checkpoint == 0:
            init = tf.global_variables_initializer()
            sess.run(init)
        print("Training start")
        
        with open(sample_directory+'/result.csv', 'w', newline ='') as allcsvfile:
                writer = csv.writer(allcsvfile, delimiter=',')
                
                for i in range(start_epoch, iterations): #range(iterations)
                    for ii in range(len(mgram_data)//batch_size):
                        
                        #Sample random noise for G or Generate a random z batch
                        zs = np.random.uniform(-1.0,1.0,size=[batch_size,z_size]).astype(np.float32) 
                        
                        # Get images, reshape and rescale to pass to D
                        xs,_ = helper.next_batch_cond(batch_size, mgram_data, mgram_labels, cond,IMG_WIDTH, IMG_HEIGHT, dataset, i)
                        #xs=cv2.resize(xs, (RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT), interpolation=cv2.INTER_CUBIC)
                        xs=np.resize(xs, (1, RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT, batch_size))
                        xs = (np.reshape(xs,[batch_size,RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT,1]) - 0.5) * 2.0 #Transform it to be between -1 and 1
                        
                        #batch_images = batch[0].reshape((batch_size, 784))
                        #batch_images = batch_images*2 - 1
                        # Sample random noise for G   batch_z = np.random.uniform(-1, 1, size=(batch_size, z_size))
                        
                        # Run optimizers
                        _ = sess.run(trainerD, feed_dict={real_in: xs, z_in: zs})
                        _ = sess.run(trainerG, feed_dict={z_in: zs})
            
                    
                    dLoss = sess.run(d_loss,{z_in:zs,real_in:xs}) #Update the discriminator
                    gLoss = g_loss.eval({z_in: zs}) #sess.run([update_G,g_loss],feed_dict={z_in:zs}) #Update the generator, twice for good measure.
                    #_,gLoss = sess.run([update_G,g_loss],feed_dict={z_in:zs})
                    
                    [acc_fake, acc_real, acc] = sess.run([accuracy_fake, accuracy_real, total_accuracy],
                      feed_dict={z_in:zs,real_in:xs})
                    
                    if i % 1 == 0:
                        #history[i, 0]=gLoss
                        #history[i, 1]=dLoss
                        
                        true_acc1=acc_real*100#true_acc[i]=acc_real*100
                        fake_acc1=acc_fake*100#fake_acc[i]=acc_fake*100
                        tot_acc1=acc*100#tot_acc[i]=acc*100
                                
                        z2 = np.random.uniform(-1.0,1.0,size=[batch_size,z_size]).astype(np.float32) #Generate another z batch
                        newZ = sess.run(Gz,feed_dict={z_in:z2}) #Use new z to get sample images from generator.

                        newZ_filt = helper.filt(newZ[0],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT)
                        if not os.path.exists(sample_directory):
                            os.makedirs(sample_directory)
                        #Save sample generator images for viewing training progress.
                        #newZint = interpolate(newZ[0])
                        newZ_filt=np.resize(newZ_filt, (SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT))
                            
                        if i % 100 == 0 and i != 0:                              
                            helper.save_images(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]),[1,1],sample_directory+'/'+cond+'_'+str(i)+'.png')    
                            for i_j in range(int(9)):
                                subplot = pyplot.subplot(3, 3, 1+i_j)
                                pyplot.axis('on')
                                pyplot.imshow(helper.filt(newZ[i_j],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT),
                                              cmap="Greys", interpolation="none")
                            
                            #pyplot.imshow(newZ_filt, cmap="Greys", interpolation="none")
                            pyplot.show()
                        #images.append(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))
                        fieldvalues = [gLoss, dLoss, true_acc1, fake_acc1, tot_acc1] 
                        writer.writerow(fieldvalues)
                        #writer.flush()
                        
                        epoch_log="Epoch "+str(i+1)+" "+"Gen Loss " + str(gLoss) + " Disc Loss: " + str(dLoss) +" True accuracy " + str(true_acc1) + " Fake accuracy: " + str(fake_acc1)+ " Total accuracy: " + str(tot_acc1)+"\n"
                        with open(sample_directory+'/result.txt', 'a') as f:
                            f.write(epoch_log)
                            f.flush()
                        print(epoch_log)
                    
                    if i % number_of_epoch_to_checkpoint == 0 and i != 0:
                        if not os.path.exists(model_directory):
                            os.makedirs(model_directory)
                        saver.save(sess,model_directory+'/model-'+str((i+1))+'.cptk')
                    
    
    # model_summary()   
    # Loading previous network to generate additional images
    testIterations=1000 #1000
    e_fake_acc = np.zeros(testIterations, dtype=np.float64)
    e_fake_loss= np.zeros(testIterations, dtype=np.float64)
    batch_size_sample = 16
    model_directory = superdir # Directory to save trained model to.
    init = tf.global_variables_initializer()
    saver = tf.train.Saver(var_list=g_vars)
    synth_images=[]
    all_checkpoints={'AD':64451, #'MS':53051, 'CALC':25701, #'ASY':8751
             }
    malignTypes=['AD', #'MS', 'CALC', #'ASY'
            ]
    for i in range(len(malignTypes)):
        cond =malignTypes[i]
        synth_sample_directory = superdir+'figs_cancer_synth/'+cond #Directory to save sample images from generator in.
        if not os.path.exists(synth_sample_directory):
            os.makedirs(synth_sample_directory)
            
        with tf.Session(config=tf.ConfigProto(log_device_placement=True)) as sess:
            sess.run(init)
            #Reload the model.
            checkpoint='model-'+str(all_checkpoints[cond])+'.cptk.data-00000-of-00001'
            checkpoint=''
            path =model_directory+'Results/'+cond+'/'  #'./models_cancer/'
            print('Loading Model... '+path)            
            #ckpt = tf.train.get_checkpoint_state(model_directory) latest_checkpoint 4901, 1676
            #ckpt = tf.train.import_meta_graph(model_directory+'model-'+str(num_checkpoint)+'.cptk.meta')
            ckpt =tf.train.latest_checkpoint(path)
            #ckpt = tf.train.get_checkpoint_state(path)
            saver.restore(sess,ckpt)
                    
            for j in range(testIterations):
                #pdb.set_trace()
                zs = np.random.uniform(-1.0,1.0,size=[batch_size_sample,z_size]).astype(np.float32) #Generate a random z batch
                newZ = sess.run(Gz,feed_dict={z_in:zs}) #Use new z to get sample images from generator.
                gLoss = g_loss.eval({z_in: zs})
                newZ_filt = helper.filt(newZ[0],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT)
                [acc_fake] = sess.run([accuracy_fake],feed_dict={z_in:zs})
                e_fake_acc[j]=acc_fake*100
                e_fake_loss[j]=gLoss
                
                newZ_filt=np.resize(newZ[0], (SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT))
                syn_img=np.reshape(newZ_filt,[1, SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT])
                synth_images.append(syn_img)
                #helper.save_images(syn_img,[1,1],synth_sample_directory+'/'+cond+'_'+str(j)+'.png')
                for i_j in range(int(9)):
                    subplot = pyplot.subplot(3, 3, 1+i_j)
                    pyplot.axis('off')
                    img=helper.filt(newZ[i_j],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT)
                    #cv2.imwrite(synth_sample_directory+'/'+cond+'_tmp_'+str(j)+'.png', img)
                    plt.imsave(synth_sample_directory+'/'+cond+'_avt_'+str(j)+'.png', img)
                    pyplot.imshow(img, cmap="Greys", interpolation="none")
                pyplot.show()    

            N = testIterations
            plt.style.use('classic')
            plt.figure()
            plt.plot(np.arange(0, N), e_fake_acc, label='GenAcc')
            plt.xlabel("Epoch #")
            plt.ylabel("Accuracy")
            plt.legend(loc="lower left")
            plt.show()
            
            plt.figure()
            plt.plot(np.arange(0, N), e_fake_loss, label='GenLoss')
            plt.xlabel("Epoch #")
            plt.ylabel("Loss")
            plt.legend(loc="lower left")
            plt.show()