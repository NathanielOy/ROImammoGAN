# -*- coding: utf-8 -*-
"""
Created on Wed May 19 11:48:35 2021

@author: Oyelade
"""
from numpy import cov
from numpy import trace
from numpy import iscomplexobj
from numpy import asarray
from numpy.random import randint
from scipy.linalg import sqrtm
import tensorflow as tf
from tensorflow.keras import backend as k
from tensorflow.keras.applications.inception_v3 import InceptionV3
from keras.applications.inception_v3 import preprocess_input
from skimage.transform import resize
from numpy import concatenate, savetxt, array
from csv import DictWriter
from os import getcwd, path, makedirs
from pandas import read_csv
import math
import numpy as np
import cv2
import os
import matplotlib.pyplot as plt
from skimage import data, img_as_float
#from skimage.measure import
#from skimage.metrics import structural_similarity as ssim
import random
from skimage.measure import compare_mse
#import image_similarity_measures
#from image_similarity_measures.quality_metrics import fsim, rmse, sam, sre, ssim, uiq,
import sys
sys.path.append('../')
sys.path.append('../brisque')
#print(sys.path)
from brisque import BRISQUE #Perception based Image Quality Evaluator 
import imquality.brisque as brisque
import PIL.Image
from metrics.pique import piqe
from metrics.niqe import niqe
from metrics import gs
from scipy import ndimage
import phasepack #.phasecongmono
#from metrics.brisque import brisque

'''
import image_similarity_measures 
from image_similarity_measures.quality_metrics import rmse, psnr
pip install image-similarity-measures
pip install scikit-image
'''
class ComputeMetrics(object):
    FEATURE='feature'
    REF='ref'
    NONREF='nonref'
    
    def __init__(self, number_rounding=3):
        self.number_rounding = number_rounding
    
    def _mse__(self, img_org, img):
        mse = compare_mse(img_org, img)
        return mse
    
    def _img_quality__(self, img_path): #pip install image-quality
        img = PIL.Image.open(img_path)
        score=brisque.score(img)
        return score
    
    def _brisque__(self, img_path): #pip install --process-dependency-links pybrisque
        brisq = BRISQUE()
        feature=brisq.get_feature(img_path)
        score=brisq.get_score(img_path)
        return score, feature
    
    def _calculate_psnr__(self, img1, img2):
        # img1 and img2 have range [0, 255]
        img1 = img1.astype(np.float64)
        img2 = img2.astype(np.float64)
        mse = np.mean((img1 - img2)**2)
        if mse == 0:
            return float('inf')
        return 20 * math.log10(255.0 / math.sqrt(mse))
    
    def _ssim__(self, img1, img2):
        C1 = (0.01 * 255)**2
        C2 = (0.03 * 255)**2
        img1 = img1.astype(np.float64)
        img2 = img2.astype(np.float64)
        kernel = cv2.getGaussianKernel(11, 1.5)
        window = np.outer(kernel, kernel.transpose())
        mu1 = cv2.filter2D(img1, -1, window)[5:-5, 5:-5]  # valid
        mu2 = cv2.filter2D(img2, -1, window)[5:-5, 5:-5]
        mu1_sq = mu1**2
        mu2_sq = mu2**2
        mu1_mu2 = mu1 * mu2
        sigma1_sq = cv2.filter2D(img1**2, -1, window)[5:-5, 5:-5] - mu1_sq
        sigma2_sq = cv2.filter2D(img2**2, -1, window)[5:-5, 5:-5] - mu2_sq
        sigma12 = cv2.filter2D(img1 * img2, -1, window)[5:-5, 5:-5] - mu1_mu2
        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) *
                                                                (sigma1_sq + sigma2_sq + C2))
        return ssim_map.mean()


    def _calculate_ssim__(self, img1, img2):
        '''calculate SSIM
        the same outputs as MATLAB's
        img1, img2: [0, 255]
        '''
        if not img1.shape == img2.shape:
            raise ValueError('Input images must have the same dimensions.')
        if img1.ndim == 2:
            return self._ssim__(img1, img2)
        elif img1.ndim == 3:
            if img1.shape[2] == 3:
                ssims = []
                for i in range(3):
                    ssims.append(self._ssim__(img1, img2))
                return np.array(ssims).mean()
            elif img1.shape[2] == 1:
                return self._ssim__(np.squeeze(img1), np.squeeze(img2))
        else:
            raise ValueError('Wrong input image dimensions.')

    def _full_reference_input_check__(self, img0, img1, sigma, nlevels, L):
        """Checks full reference quality measures for valid inputs."""
        if nlevels <= 0:
            raise ValueError('nlevels must be >= 1.')
        if sigma < 1.2:
            raise ValueError('sigma < 1.2 is effective meaningless.')
        if np.min(img0.shape) / (2**(nlevels - 1)) < sigma * 2:
            raise ValueError(
                "{nlevels} levels makes {shape} smaller than a filter"
                " size of 2 * {sigma}".format(
                    nlevels=nlevels, shape=img0.shape, sigma=sigma
                )
            )
        if L is not None and L < 1:
            raise ValueError("Dynamic range must be >= 1.")
        if img0.shape != img1.shape:
            raise ValueError(
                "original and reconstruction should be the " + "same shape"
            )
        
    def _fsim__(self, img0, img1, nlevels=1, nwavelets=16, L=None):
      img0=np.resize(img0, (299, 299))
      img1=np.resize(img1, (299, 299))
      self._full_reference_input_check__(img0, img1, 1.2, nlevels, L)
      if nwavelets < 1:
          raise ValueError('There must be at least one wavelet level.')

      Y1 = img0
      Y2 = img1
      
      scales = np.zeros(nlevels)
      mets = np.zeros(nlevels)
      maps = [None] * nlevels
 
      for level in range(0, nlevels):
          # sigma = 1.2 is approximately correct because the width of the scharr
          # and min wavelet filter (phase congruency filter) is 3.
          sigma = 1.2 * 2**level
 
          F = 2  # Downsample (using ndimage.zoom to prevent sampling bias)
          Y1 = ndimage.zoom(Y1, 1/F)
          Y2 = ndimage.zoom(Y2, 1/F)
 
          # Calculate the phase congruency maps
          [PC1, Orient1, ft1, T1] = phasepack.phasecongmono(Y1, nscale=nwavelets)
          [PC2, Orient2, ft2, T2] = phasepack.phasecongmono(Y2, nscale=nwavelets)
 
          # Calculate the gradient magnitude map using Scharr filters
          dx = np.array([[3., 0., -3.],
                         [10., 0., -10.],
                         [3., 0., -3.]]) / 16
          dy = np.array([[3., 10., 3.],
                         [0., 0., 0.],
                         [-3., -10., -3.]]) / 16
          IxY1 = ndimage.filters.convolve(Y1, dx)
          IyY1 = ndimage.filters.convolve(Y1, dy)
          gradientMap1 = np.sqrt(IxY1**2 + IyY1**2)

          IxY2 = ndimage.filters.convolve(Y2, dx)
          IyY2 = ndimage.filters.convolve(Y2, dy)
          gradientMap2 = np.sqrt(IxY2**2 + IyY2**2)

          # Calculate the FSIM
          T1 = 0.85   # fixed and depends on dynamic range of PC values
          T2 = 160    # fixed and depends on dynamic range of GM values
          PCSimMatrix = (2 * PC1 * PC2 + T1) / (PC1**2 + PC2**2 + T1)
          gradientSimMatrix = ((2 * gradientMap1 * gradientMap2 + T2) /
                               (gradientMap1**2 + gradientMap2**2 + T2))
          PCm = np.maximum(PC1, PC2)
          FSIMmap = gradientSimMatrix * PCSimMatrix
          FSIM = np.sum(FSIMmap * PCm) / np.sum(PCm)

          scales[level] = sigma
          mets[level] = FSIM
          maps[level] = FSIMmap

      return FSIM, scales, mets, maps  
    
    def _calculate_fid__(self, images1, images2):
        # prepare the inception v3 model
        model = InceptionV3(include_top=False, pooling='avg', input_shape=(3, 299,299))
        # calculate activations
        images1=np.resize(images1, (3, 299, 299))
        images1 = tf.expand_dims(images1, axis=0)
        images2=np.resize(images2, (3, 299, 299))
        images2 = tf.expand_dims(images2, axis=0)
        act1 = model.predict(images1)
        act2 = model.predict(images2)
        # calculate mean and covariance statistics
        mu1, sigma1 = act1.mean(axis=0), cov(act1, rowvar=False)
        mu2, sigma2 = act2.mean(axis=0), cov(act2, rowvar=False)
        # calculate sum squared difference between means
        ssdiff = np.sum((mu1 - mu2)**2.0)
        # calculate sqrt of product between cov
        covmean =math.sqrt(sigma1.dot(sigma2)) # sqrtm(sigma1.dot(sigma2))
        # check and correct imaginary numbers from sqrt
        if iscomplexobj(covmean):
            covmean = covmean.real
        # calculate score
        fid = ssdiff + (sigma1 + sigma2 - 2.0 * covmean) #trace(sigma1 + sigma2 - 2.0 * covmean)
        return fid
    
    def _compute_geometry_score__(self, org_img, syn_img):
        org_img = np.reshape(org_img, (-1, 299*299))
        syn_img = np.reshape(syn_img, (-1, 299*299))
        rlts_org_img = gs.rlts(org_img, gamma=1.0/128, n=100)    
        rlt_org_img = np.mean(rlts_org_img, axis=0)       
        rlts_syn_img = gs.rlts(syn_img, gamma=1.0/128, n=100)    
        rlt_syn_img = np.mean(rlts_syn_img, axis=0)       
        geometry_score=gs.geom_score(rlt_org_img, rlt_syn_img)
        #gs.fancy_plot(rlt_org_img, label='MRLT of Org')
        #gs.fancy_plot(rlt_syn_img, label='MRLT of Syn')
        #plt.xlim([0, 30])
        #plt.legend()
        return geometry_score
    
    def _referecence_metrics__(self, imgs):
          n=0
          metrics=[]
          for im in imgs:
              org_img, img=im
              psnr=self._calculate_psnr__(org_img, img)
              ssimc=self._calculate_ssim__(org_img, img)
              mse_score=self._mse__(org_img, img)
              fsim_score, _, _, _=self._fsim__(org_img, img)
              if n==0:
                  print('PSNR:  '+str(psnr))
                  print('SSIM:  '+str(ssimc))
                  print('MSE:  '+str(mse_score))
                  print('FSIM:  '+str(fsim_score))       
                  n=n+1
              img_metrics=psnr, ssimc, mse_score, fsim_score
              metrics.append(img_metrics)
          return metrics
      
    def _non_referecence_metrics__(self, imgs):
          n=0
          metrics=[]
          for im in imgs:
              img_path, img=im
              brisqu=cmp_metrcis._brisque__(img_path)
              brisqu_score=brisqu[0]
              brisqu_features=brisqu[1]
              brisqu_score2=cmp_metrcis._img_quality__(img_path)
              pque_score, NoticeableArtifactsMask, NoiseMask, ActivityMask=piqe(img)
              niqe_score=niqe(img)
              #brisque_score=brisque(img)
              if n==0:
                  print('BRISQUE Score v1:  '+str(brisqu[0]))
                  print('BRISQUE Feature:  '+str(brisqu[1]))
                  print('BRISQUE Score v2:  '+str(brisqu_score2))
                  print('PIQE Score:  '+str(pque_score))
                  print('NIQE Score:  '+str(niqe_score))              
                  #print('BRISQUE Score v3:  '+str(brisque_score))
                  n=n+1
              img_metrics=brisqu_score, brisqu_score2, brisqu_features, pque_score, niqe_score
              metrics.append(img_metrics)
          return metrics
      
    def _feature_based_metrics__(self, imgs):
          n=0
          metrics=[]
          for im in imgs:
              images1, images2=im
              geometry_score=self._compute_geometry_score__(images1, images2)
              fid_same_score = self._calculate_fid__(images1, images1) # fid between images1 and images1
              fid_diff_score = self._calculate_fid__(images1, images2) # fid between images1 and images2
              if n==0:
                  print('Geometry Score: %.3f' % geometry_score)              
                  print('FID (same): %.3f' % fid_same_score)              
                  print('FID (different): %.3f' % fid_diff_score)
                  n=n+1
              img_metrics=geometry_score, fid_same_score, fid_diff_score
              metrics.append(img_metrics)
          return metrics
      
    def _save_results_to_csv__(self, item=None, filename=None, pathsave=None):
            check_directory = getcwd() + "/" + pathsave
            if not path.exists(check_directory):
                makedirs(check_directory)
            with open(pathsave + filename + ".csv", 'a') as file:
                w = DictWriter(file, delimiter=',', lineterminator='\n', fieldnames=item.keys())
                if file.tell() == 0:
                    w.writeheader()
                w.writerow(item)
        
    def _save_solutions_to_csv__(self, solutions=None, filename=None, pathsave=None):
            savetxt(pathsave + filename + ".csv", array(solutions), delimiter=",")
            return None

    def _save_result__(self, abnormality, metrics):
          log_filename='metrics'#metric_type
          path_save_result='./Results/'
          mkeys={self.REF:['psnr', 'ssimc', 'mse_score', 'fsim_score'], 
                self.NONREF:['brisqu_score', 'brisqu_score2', 'brisqu_features', 'pque_score', 'niqe_score'], 
                self.FEATURE:['geometry_score', 'fid_same_score', 'fid_diff_score']
                }
          for metric_ref, metric_nonref, metric_feature in metrics: #each row of metrics: since we have run metrics for N images
              scorekeys=mkeys[self.REF]+mkeys[self.NONREF]+mkeys[self.FEATURE]
              print(scorekeys)
              result = {'image_type':abnormality}
              metric_values_4_row_i=metric_ref+metric_nonref+metric_feature
              n=0
              for score in scorekeys:
                  result[score]=metric_values_4_row_i[n]
                  n=n+1
              self._save_results_to_csv__(result, log_filename, path_save_result)
              
#CNN diagrams: https://towardsdatascience.com/deep-image-quality-assessment-30ad71641fac
#Geometry Score: https://arxiv.org/abs/1802.02664
#Sample Works
#https://www.researchgate.net/publication/332369297_Single_image_defocus_estimation_by_modified_gaussian_function
#https://ieeexplore.ieee.org/document/6272356
#https://www.sciencedirect.com/science/article/pii/S0895611119300990
#All metrics: https://github.com/photosynthesis-team/piq
if __name__ == "__main__":
    cmp_metrcis=ComputeMetrics(2)
    IMG_WIDTH=299
    IMG_HEIGHT=299     
    synthesize_dirs='./figs_cancer_synth/'
    root_orig_path='./gansMIASSmall/'  
    dim=(IMG_WIDTH, IMG_HEIGHT, 3)
    
    '''
    single_synimg_path=synthesize_dirs+'AD/AD_avt_0.png'
    single_orgimg=root_orig_path+'all_normal/NORM_7.png'
    single_synimg=cv2.imread(single_synimg_path)
    single_orgimg=cv2.imread(single_orgimg)
    single_synimg=np.resize(single_synimg, dim)
    imgs=single_orgimg, single_synimg
    cmp_metrcis._referecence_metrics__([imgs])
    cmp_metrcis._non_referecence_metrics__([(single_synimg_path, single_synimg)])
    cmp_metrcis._feature_based_metrics__([imgs])
    '''
    orig_path={#'AD':'all_architectural_distortion_augmented',
               #'MS':'all_mass_augmented', 
               #'CALC':'all_calcifications_augmented', 
               'ASY':'all_asymetry_augmented'
               }
    dataset_dirs=[#'AD',
            #'MS', 
            #'CALC', 
            'ASY'
            ]
    for input_dataset in dataset_dirs:
        dataset=synthesize_dirs+input_dataset+'/'
        images=os.listdir(dataset) 
        org_img_dir=root_orig_path+orig_path[input_dataset]+'/'        
        org_imgs_in_dir=os.listdir(org_img_dir)
        imgs=[]
        imgs_paths=[]
        limit=10 #number of synthesized images we want to sample
        i=0
        for img_path in images:            
            if i < limit:
                org_img=org_imgs_in_dir[random.randint(2, len(org_imgs_in_dir)-5)]
                org_img=cv2.imread(org_img_dir+org_img)
                syn_path=dataset+img_path
                img=cv2.imread(syn_path)
                plt.imshow(img, cmap="Greys", interpolation="none")                                
                img=np.resize(img, dim)
                imgs.append((org_img, img))
                imgs_paths.append((syn_path, img))
                i=i+1
        ref_metrics=cmp_metrcis._referecence_metrics__(imgs)
        nonref_metrics=cmp_metrcis._non_referecence_metrics__(imgs_paths)
        feature_metrics=cmp_metrcis._feature_based_metrics__(imgs)
        metrics=[]
        for i in range(limit):
            metrics.append((ref_metrics[i], nonref_metrics[i], feature_metrics[i]))
        cmp_metrcis._save_result__(input_dataset, metrics)            
        