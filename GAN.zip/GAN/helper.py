import tensorflow as tf
import numpy as np
import scipy.misc
import cv2
import skimage.transform
import sklearn.preprocessing
from matplotlib import pyplot
from skimage.transform import resize
import os
import imageio

#This function performns a leaky relu activation, which is needed for the discriminator network.
def lrelu(x, leak=0.2, name="lrelu"):
     with tf.compat.v1.variable_scope(name):
         f1 = 0.5 * (1 + leak)
         f2 = 0.5 * (1 - leak)
         return f1 * x + f2 * abs(x)

#The below functions are taken from carpdem20's implementation https://github.com/carpedm20/DCGAN-tensorflow
#They allow for saving sample images from the generator to follow progress
def save_images(images, size, image_path):
    return imsave(images, size, image_path)
    #return imsave(inverse_transform(images), size, image_path)

def filt(images,IMG_WIDTH,IMG_HEIGHT):
    norm = sklearn.preprocessing.minmax_scale(np.reshape(images,(IMG_WIDTH,IMG_HEIGHT)), (-0.999,0.999))
    rescale = skimage.transform.rescale(norm,1.625)
    kernel = np.ones((1,1),np.float32)/25
    return cv2.filter2D(rescale,-1,kernel)

def imsave(images, size, path):
    img_uint8 = merge(images, size).astype(np.uint8)
    return imageio.imwrite(path, img_uint8)
    #return scipy.misc.imsave(path, merge(images, size))

def inverse_transform(images):
    return (images+1.)/2.

def merge(images, size):
    h, w = images.shape[1], images.shape[2]
    img = np.zeros((h * size[0], w * size[1]))

    for idx, image in enumerate(images):
        i = idx % size[1]
        j = idx // size[1]
        img[j*h:j*h+h, i*w:i*w+w] = image
    return img

# For getting batches
def next_batch(num, data, labels, cond, IMG_WIDTH,IMG_HEIGHT, dataset):
    '''
    Return a total of `num` random samples and labels.
    '''
    idx = np.arange(0 , len(data))
    np.random.shuffle(idx)
    idx = idx[:num]
    data_shuffle = [data[ i] for i in idx]
    labels_shuffle = [labels[ i] for i in idx]

    return np.asarray(data_shuffle), np.asarray(labels_shuffle)

# For getting batches with a specific diagnosis
def next_batch_cond(num, data, labels, cond, IMG_WIDTH,IMG_HEIGHT, dataset, k):
    '''
    Return a total of `num` random samples and labels.
    '''
    data_con=[]
    label_con = []
    
    #idcon = np.arange(0,len(data))
    for j in np.arange(0,len(data)):
        if labels[j] == cond:
            data_con.append(data[j])
            label_con.append(labels[j])

    idx = np.arange(0,len(data_con))
    np.random.shuffle(idx)
    idx = idx[:num]
    data_shuffle = [data_con[i] for i in idx]
    labels_shuffle = [label_con[i] for i in idx]
    superdir='./'#'./'#
    cond_directory=superdir+'augmentedsample/'+dataset+'/'+cond
    if not os.path.exists(cond_directory):
        os.makedirs(cond_directory)
    for i in np.arange(0,len(data_shuffle)):
        save_images(np.reshape(data_shuffle[i],[1,IMG_WIDTH,IMG_HEIGHT]),[1,1],cond_directory+'/'+cond+'_'+labels_shuffle[i]+'_'+str(i)+'.png')
    
    if k < 1 :
        # plot images from the training dataset
        for i in np.arange(0, int(len(data_shuffle)/2)):
            pyplot.subplot(4, 4, 1 + i) 
            pyplot.axis('off')
            img= np.reshape(data_shuffle[i],[IMG_WIDTH,IMG_HEIGHT])
            pyplot.imshow(img, cmap='gray') # plot raw pixel data
        pyplot.show()
    
    
    return np.asarray(data_shuffle), np.asarray(labels_shuffle)
