import matplotlib
matplotlib.use('Agg')
import tensorflow as tf
from numpy import expand_dims
from numpy import zeros
from numpy import ones
from numpy.random import randn
from numpy.random import randint
from keras.datasets.mnist import load_data
from keras.optimizers import Adam
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Reshape
from keras.layers import Flatten
from keras.layers import Conv2D
from keras.layers import Conv2DTranspose
from keras.layers import LeakyReLU
from keras.layers import BatchNormalization
from keras.initializers import RandomNormal

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot
import tensorflow.contrib.slim as slim
import os
import scipy.misc
import scipy
import readMammograms
import random
import cv2
import skimage.transform
import sklearn.preprocessing
import helper
import pdb
import csv
from numpy.random import choice

# example of smoothing class=1 to [0.7, 1.2]
def smooth_positive_labels(y):
	return y - 0.3 + (random(y.shape) * 0.5)
 
# randomly flip some labels
def noisy_labels(y, p_flip=0.05):  # flip labels with 5% probability
	# determine the number of labels to flip
	n_select = int(p_flip * y.shape[0])
	# choose labels to flip
	flip_ix = choice([i for i in range(y.shape[0])], size=n_select)
	# invert the labels in place
	y[flip_ix] = 1 - y[flip_ix]
	return y

def define_generator(latent_dim):
	# weight initialization
	'''
    init = RandomNormal(stddev=0.02)
	# define model
	model = Sequential()
	# foundation for 7x7 image
	n_nodes = 38*38*256
	model.add(Dense(n_nodes, kernel_initializer=init, input_dim=latent_dim))
	model.add(LeakyReLU(alpha=0.2))
	model.add(Reshape((38, 38, 256)))
	
	model.add(Conv2DTranspose(64, (4,4), strides=(2,2), padding='same', kernel_initializer=init))
	model.add(BatchNormalization())
	model.add(LeakyReLU(alpha=0.2))
	
	model.add(Conv2DTranspose(32, (4,4), strides=(2,2), padding='same', kernel_initializer=init))
	model.add(BatchNormalization())
	model.add(LeakyReLU(alpha=0.2))
    
    model.add(Conv2DTranspose(16, (4,4), strides=(2,2), padding='same', kernel_initializer=init))
	model.add(BatchNormalization())
	model.add(LeakyReLU(alpha=0.2))
	'''
	model.add(Conv2D(1, (7,7), activation='tanh', padding='same', kernel_initializer=init))
	return model
def define_discriminator(in_shape=(28,28,1)):
	# weight initialization
	'''
    init = RandomNormal(stddev=0.02)
	# define model
	model = Sequential()
	model.add(Conv2D(16, (4,4), strides=(2,2), padding='same', kernel_initializer=init, input_shape=in_shape))
	model.add(BatchNormalization())
	model.add(LeakyReLU(alpha=0.2))
    
	model.add(Conv2D(32, (4,4), strides=(2,2), padding='same', kernel_initializer=init))
	model.add(BatchNormalization())
	model.add(LeakyReLU(alpha=0.2))
	
    model.add(Conv2D(64, (4,4), strides=(2,2), padding='same', kernel_initializer=init))
	model.add(BatchNormalization())
	model.add(LeakyReLU(alpha=0.2))
    '''
    # classifier
	model.add(Flatten())
	model.add(Dense(1, activation='sigmoid'))
	# compile model
	opt = Adam(lr=0.0002, beta_1=0.5)
	model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
	return model 
# summarize 
def model_summary():
    model_vars = tf.trainable_variables()
    slim.model_analyzer.analyze_vars(model_vars, print_info=True)

# Define generator network
def generator(z):

    zP = slim.fully_connected(z,38*38*256,normalizer_fn=slim.batch_norm,
        activation_fn=tf.nn.relu,scope='g_project',weights_initializer=initializer)

    zCon = tf.reshape(zP,[-1,38,38,256])

    gen1 = slim.convolution2d_transpose(zCon,num_outputs=512,kernel_size=[5,5], #64, 512
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv1', weights_initializer=initializer)

    gen2 = slim.convolution2d_transpose(gen1,num_outputs=256,kernel_size=[5,5], #32, 256
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv2', weights_initializer=initializer)

    gen3 = slim.convolution2d_transpose(gen2,num_outputs=128,kernel_size=[5,5], #16,  128
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv3', weights_initializer=initializer)
    '''
    gen4 = slim.convolution2d_transpose(gen3,num_outputs=8,kernel_size=[5,5],
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv4', weights_initializer=initializer)

    gen5 = slim.convolution2d_transpose(gen4,num_outputs=4,kernel_size=[5,5],
        stride=[1,1],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv5', weights_initializer=initializer)
    '''
    g_out = slim.convolution2d_transpose(gen3,num_outputs=1,kernel_size=[32, 32],
        padding="SAME",biases_initializer=None,activation_fn=tf.nn.tanh,scope='g_out',
        weights_initializer=initializer)

    return g_out

# Define descriminator network
def discriminator(bottom, reuse=False):

    dis1 = slim.convolution2d(bottom,64,[4,4],stride=[2,2],padding="SAME", #16,  64
        biases_initializer=None,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv1',
        weights_initializer=initializer)

    dis2 = slim.convolution2d(dis1,128,[4,4],stride=[2,2],padding="SAME", #32,  128
        normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv2',
        weights_initializer=initializer)

    dis3 = slim.convolution2d(dis2,256,[4,4],stride=[2,2],padding="SAME", #64,  256
        normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv3',
        weights_initializer=initializer)

    '''
    dis4 = slim.convolution2d(dis3,64,[4,4],stride=[1,1],padding="SAME",
          normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv4',
          weights_initializer=initializer)
    
    dis5 = slim.convolution2d(dis4,64,[4,4],stride=[1,1],padding="SAME",
          normalizer_fn=slim.batch_norm,activation_fn=helper.lrelu,reuse=reuse,scope='d_conv5',
          weights_initializer=initializer)
    '''
    out=slim.flatten(dis3)
    d_out = slim.fully_connected(out,1,activation_fn=tf.nn.sigmoid,
    reuse=reuse,scope='d_out', weights_initializer=initializer)
    
    
    return d_out, out

def model_loss(input_real, input_z, out_channel_dim, alpha=0.2, smooth_factor=0.1): 
    d_model_real, d_logits_real = discriminator(input_real, alpha=alpha)

    d_loss_real = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_real,
                                                labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))

    input_fake = generator(input_z, out_channel_dim, alpha=alpha)
    d_model_fake, d_logits_fake = discriminator(input_fake, reuse=True, alpha=alpha)
    
    d_loss_fake = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake, labels=tf.zeros_like(d_model_fake)))
    
    g_loss = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake, labels=tf.ones_like(d_model_fake)))
    return d_loss_real + d_loss_fake, g_loss

#tests.test_model_loss(model_loss)
def model_inputs(image_width, image_height, image_channels, z_dim):
    """
    Create the model inputs
    :param image_width: The input image width
    :param image_height: The input image height
    :param image_channels: The number of image channels
    :param z_dim: The dimension of Z
    :return: Tuple of (tensor of real input images, tensor of z data, learning rate)
    """
    real_input_images = tf.placeholder(tf.float32, [None, image_width, image_height, image_channels], 'real_input_images')
    input_z = tf.placeholder(tf.float32, [None, z_dim], 'input_z')
    learning_rate = tf.placeholder(tf.float32, [], 'learning_rate')
    return real_input_images, input_z, learning_rate


#######################################################################################33333
    #BEGIN Train settings and running
#########################################################################################
learning_rateG=0.00001  #1e-4  0.00025
learning_rateD=0.00004  #0.00025
betaG=0.5 #0.45
betaD=0.5 #0.45
beta2G=0.999
beta2D=0.999
epsilon=1e-08

fixed_batch_size=32
dataset='gansMIASSmall'  #Inbreast, gansMIASLarge,  gansMIASSmall, gansDDSM  
IMG_WIDTH=299 #32, 299 1024  2560  
IMG_HEIGHT=299  #32, 299  1024 3328

SAVE_IMG_WIDTH=494 #52, 32, 299 1024  2560
SAVE_IMG_HEIGHT=494  #52, 32, 299  1024 3328

#MIAS(small and large) ['MS', 'CALC', 'ARCH', 'ASYM', 'NORM', 'B', 'M', 'CIRC', 'SPIC', 'MISC']
#DDSM labels ['MS', 'CALC', 'AD', 'ASY', 'N', 'B', 'M'] 
#["MS", "CALC", "AD", "ASY", 'N', 'B', 'M']
malignTypes=["ARCH"] #, "CALC", "AD", "ASY", "N", 'B', 'M']
iterations = 20000 # 5000, Total number of iterations to use.
testIterations=1000 #1000

for i in range(len(malignTypes)):
    
    print("Loading in Mammogram data...")
    mgrams = readMammograms.readData(i, IMG_WIDTH)
    mgram_data = mgrams.data
    mgram_labels = mgrams.labels
    print("Mammogram data loaded.\n")

    # Connecting generator and discriminator networks
    tf.reset_default_graph()
    
    z_size = 100 #Size of z vector used for generator.
    
    #This initializaer is used to initialize all the weights of the network.
    initializer = tf.contrib.layers.variance_scaling_initializer(dtype=tf.float32) #He initializer
                #tf.truncated_normal_initializer(stddev=0.02)
    
    #These two placeholders are used for input into the generator and discriminator, respectively.
    z_in = tf.placeholder(shape=[None,z_size],dtype=tf.float32) #Random vector
    real_in = tf.placeholder(shape=[None,IMG_WIDTH,IMG_HEIGHT,1],dtype=tf.float32) #Real images
    
    Gz = generator(z_in) #Generates images from random z vectors
    Dx, d_model_real = discriminator(real_in) #Produces probabilities for real images
    Dg, d_model_fake = discriminator(Gz,reuse=True) #Produces probabilities for generator images

    alpha=0.2
    smooth_factor=0.1
    '''
    d_loss_real = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=Dx,
                                                labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))
    d_loss_fake = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=Dg, labels=tf.zeros_like(d_model_fake)))
    
    g_loss = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=Dg, labels=tf.ones_like(d_model_fake)))
    '''
    
    #These functions together define the optimization objective of the GAN.
    d_loss = -tf.reduce_mean(tf.log(Dx) + tf.log(1.-Dg)) #This optimizes the discriminator.
    g_loss = -tf.reduce_mean(tf.log(Dg)) #This optimizes the generator.
    
    # Compute the discriminator accuracy on real data, fake data, and total:
    accuracy_real  = tf.reduce_mean(tf.cast(tf.equal(tf.round(Dx), tf.ones_like(Dx)), tf.float32))
    accuracy_fake  = tf.reduce_mean(tf.cast(tf.equal(tf.round(Dg), tf.zeros_like(Dg)), tf.float32))
    total_accuracy = 0.5*(accuracy_fake +  accuracy_real)
    
    tvars = tf.trainable_variables()
    #print(tvars) print(tvars[9:]) print(tvars[0:9])
    #The below code is responsible for applying gradient descent to update the GAN.
    trainerD = tf.train.AdamOptimizer(learning_rate=learning_rateD,beta1=betaD, beta2=beta2D, epsilon=epsilon)
    trainerG = tf.train.AdamOptimizer(learning_rate=learning_rateG,beta1=betaG, beta2=beta2G, epsilon=epsilon)
    d_grads = trainerD.compute_gradients(d_loss,tvars[9:]) #Only update the weights for the discriminator network.
    g_grads = trainerG.compute_gradients(g_loss,tvars[0:9]) #Only update the weights for the generator network.
    
    update_D = trainerD.apply_gradients(d_grads)
    update_G = trainerG.apply_gradients(g_grads)
            
    # Start training loop
    batch_size =0  # Size of image batch to apply at each iteration of categories of abnormalities.
    if (len(mgram_data) < fixed_batch_size):
        batch_size =len(mgram_data)
    else:
        batch_size =fixed_batch_size
    
   
    #"N",  "B", "AD", "ASY", "MS", "CALC"
    # Which condition to use: N = normal, B = benign, M = malignant, AD=architectural distortion, ASY=asymetry, MS=mass, CALC=calcification
    cond =malignTypes[i] #'MS' 
    
    if cond == "N" or cond == "NORM": # 'NORM',
        cond='N'
    elif cond == "AD" or cond == "ARCH": #'ARCH'
        cond='AD'
    elif cond == "ASY" or cond == "ASYM": #'ASYM', 'NORM',
        cond='ASY'
    else:
        cond=cond
        
    sample_directory = './figs_cancer2/'+dataset+'/'+cond # Directory to save sample images from generator in.
    model_directory = './models_cancer2/'+dataset+'/'+cond # Directory to save trained model to.
    
    history=np.zeros((iterations,iterations), dtype=np.float64)
    images   = []
    true_acc = np.zeros(iterations, dtype=np.float64)
    fake_acc = np.zeros(iterations, dtype=np.float64)
    tot_acc  = np.zeros(iterations, dtype=np.float64)
        
    init = tf.global_variables_initializer()
    saver = tf.train.Saver()
    with tf.Session() as sess:
        sess.run(init)
        print("Training start")
            
        with open(sample_directory+'/result.csv', 'w', newline ='') as allcsvfile:
                writer = csv.writer(allcsvfile, delimiter=',')
                
                for i in range(iterations):
            
                    zs = np.random.uniform(-1.0,1.0,size=[batch_size,z_size]).astype(np.float32) #Generate a random z batch
                    
                    xs,_ = helper.next_batch_cond(batch_size, mgram_data, mgram_labels, cond,IMG_WIDTH,IMG_HEIGHT, dataset)
                    xs = (np.reshape(xs,[batch_size,IMG_WIDTH,IMG_HEIGHT,1]) - 0.5) * 2.0 #Transform it to be between -1 and 1
                    _,dLoss = sess.run([update_D,d_loss],feed_dict={z_in:zs,real_in:xs}) #Update the discriminator
                    _,gLoss = sess.run([update_G,g_loss],feed_dict={z_in:zs}) #Update the generator, twice for good measure.
                    _,gLoss = sess.run([update_G,g_loss],feed_dict={z_in:zs})
                    
                    [acc_fake, acc_real, acc] = sess.run([accuracy_fake, accuracy_real, total_accuracy],
                      feed_dict={z_in:zs,real_in:xs})
                    
                    if i % 1 == 0:
                        history[i, 0]=gLoss
                        history[i, 1]=dLoss
                        
                        true_acc[i]=acc_real*100
                        fake_acc[i]=acc_fake*100
                        tot_acc[i]=acc*100
                                
                        print("Gen Loss " + str(gLoss) + " Disc Loss: " + str(dLoss))
                        print("True accuracy " + str(true_acc[i]) + " Fake accuracy: " + str(fake_acc[i])+ " Total accuracy: " + str(tot_acc[i]))
                        z2 = np.random.uniform(-1.0,1.0,size=[batch_size,z_size]).astype(np.float32) #Generate another z batch
                        newZ = sess.run(Gz,feed_dict={z_in:z2}) #Use new z to get sample images from generator.
                        print(newZ.shape)
                        newZ_filt = helper.filt(newZ[0],IMG_WIDTH,IMG_HEIGHT)
                        if not os.path.exists(sample_directory):
                            os.makedirs(sample_directory)
                        #Save sample generator images for viewing training progress.
                        #newZint = interpolate(newZ[0])
                        helper.save_images(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]),[1,1],sample_directory+'/'+cond+'_'+str(i)+'.png')
                        
                        images.append(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))
                        
                        
                        fieldvalues = [history[i, 0], history[i, 1], true_acc[i], fake_acc[i], tot_acc[i]] 
                        writer.writerow(fieldvalues)
                        
                    if i % 100 == 0 and i != 0:
                        if not os.path.exists(model_directory):
                            os.makedirs(model_directory)
                        saver.save(sess,model_directory+'/model-'+str(i)+'.cptk')
                    print("...Iteration >>> {} ", i)
    
    model_summary()
    
    
    # Loading previous network to generate additional images
    synth_images   = []
    sample_directory = './figs_cancer_synth/'+cond #Directory to save sample images from generator in.
    model_directory = './models_cancer' #Directory to load trained model from.
    batch_size_sample = 20
    path =model_directory  #'./models_cancer/'
    init = tf.global_variables_initializer()
    saver = tf.train.Saver()
    with tf.Session() as sess:
        sess.run(init)
        #Reload the model.
        print('Loading Model...')
        ckpt = tf.train.get_checkpoint_state(path)
        #saver.restore(sess,ckpt.model_checkpoint_path)
        
        for j in range(testIterations):
            #pdb.set_trace()
            zs = np.random.uniform(-1.0,1.0,size=[batch_size_sample,z_size]).astype(np.float32) #Generate a random z batch
            newZ = sess.run(Gz,feed_dict={z_in:zs}) #Use new z to get sample images from generator.
            newZ_filt = helper.filt(newZ[0],IMG_WIDTH,IMG_HEIGHT)
            if not os.path.exists(sample_directory):
                os.makedirs(sample_directory)
            helper.save_images(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]),[1,1],sample_directory+'/'+cond+'_'+str(j)+'.png')
            synth_images.append(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))


for i in range(len(malignTypes)):
    history=np.zeros((iterations,iterations), dtype=np.float64)
    true_acc=np.zeros(iterations, dtype=np.float64)
    fake_acc=np.zeros(iterations, dtype=np.float64)
    tot_acc=np.zeros(iterations, dtype=np.float64)
    cond =malignTypes[i]
    
    if cond == "N" or cond == "NORM": # 'NORM',
        cond='N'
    elif cond == "AD" or cond == "ARCH": #'ARCH'
        cond='AD'
    elif cond == "ASY" or cond == "ASYM": #'ASYM', 'NORM',
        cond='ASY'
    else:
        cond=cond
        
    sample_directory = './figs_cancer2/'+dataset+'/'+cond
    handle=sample_directory+'/result.csv'
    f=open(handle, newline ='')
    n=0
    for row in csv.reader(f, delimiter=','):
        history[n, 0]=float(row[0])
        history[n, 1]=float(row[1])
        true_acc[n]=float(row[2])
        fake_acc[n]=float(row[3])
        tot_acc[n]=float(row[4])
        
        n+=1
        
    N = iterations
    plt.style.use("ggplot")
    plt.figure()
    plt.plot(np.arange(0, N), history[0], label='GenLoss')
    plt.plot(np.arange(0, N), history[1], label='DiscLoss')
    plt.title(cond+": Training Loss on Gen/Disc")
    plt.xlabel("Epoch #")
    plt.ylabel("Loss")
    plt.legend(loc="lower left")
    plt.show()
    
    
    # Plot the accuracy values:
    fig = plt.figure()
    plt.plot(np.arange(0, N), true_acc, label="True Accuracy")
    plt.plot(np.arange(0, N), fake_acc, label="Fake Accuracy")
    plt.plot(np.arange(0, N), tot_acc, label="Total Accuracy")
    plt.grid(True)
    plt.xlabel("Epoch #")
    plt.ylabel("Accuracy")
    plt.legend(loc="lower left")
    plt.show()
    
    #images during training
    number_of_images_to_show=20
    indexes = range(N)[::20]
    image_array = np.zeros((SAVE_IMG_WIDTH*len(indexes), number_of_images_to_show*SAVE_IMG_WIDTH))
    for i, e in enumerate(indexes):
        image_set = images[e]
        for j in range(number_of_images_to_show):
            index = np.random.randint(len(image_set))
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH].shape
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH] = image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT)
            subplot = plt.subplot(5, 5, 1+j)
            plt.axis('off')
            #subplot.set_title(cond, fontsize=12) 
            plt.imshow(image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT), cmap="Greys", interpolation="none")
            
    #plt.figure(figsize=(100,100))
    #subplot = plt.subplot(5, 5)
    #subplot.set_title(cond, fontsize=12) 
    #plt.imshow(image_array, cmap="Greys", interpolation="none")
    plt.show()
    
    #images already synthesis
    number_of_images_to_show=20
    indexes = range(N)[::20]
    image_array = np.zeros((SAVE_IMG_WIDTH*len(indexes), number_of_images_to_show*SAVE_IMG_WIDTH))
    for i, e in enumerate(indexes):
        image_set = synth_images[e]
        for j in range(number_of_images_to_show):
            index = np.random.randint(len(image_set))
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH].shape
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH] = image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT)
            subplot = pyplot.subplot(5, 5, 1+j)
            pyplot.axis('off')
            #subplot.set_title(cond, fontsize=12) 
            pyplot.imshow(image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT), cmap="Greys", interpolation="none")
    #plt.figure(figsize=(20,20))
    #plt.imshow(image_array, cmap="Greys", interpolation="none")
    pyplot.show()
    
    
'''
https://medium.com/coinmonks/celebrity-face-generation-using-gans-tensorflow-implementation-eaa2001eef86
gen_cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=disc_fake,
                                                                                      labels=tf.ones_like(
                                                                                          disc_fake)))
                    disc_cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=disc_fake,
                                                                                       labels=tf.zeros_like(
                                                                                           disc_fake)))
                    disc_cost += tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=disc_real,
                                                                                        labels=tf.ones_like(
                                                                                            disc_real)))
'''
