# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 16:02:04 2020

@author: Oyelade
"""
import requests
from io import BytesIO

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from PIL import Image
from mpl_toolkits.mplot3d import Axes3D
import cv2
import matplotlib.pyplot as plt
plt.style.use('seaborn-white')
import numpy as np
import math
from matplotlib.ticker import ScalarFormatter

myfile="./graphs/"
cmap = [(0, '#2f9599'), (0.45, '#eee124'), (1, '#8800ff')]
cmap = cm.colors.LinearSegmentedColormap.from_list('Custom', cmap, N=256)

iterations = [1, 50, 100, 200, 300, 400, 500]
algorithms=['ABC','WOA',#'BOA',
            'PSO',#'QSO','CSO', 
            'EOSA', #'DE',
            'GA'#,'HGSO', 'BFO', 'EOSA2'
            ]
#benchmarkfuncs=['CEC_F1', 'CEC_F2', 'CEC_F3']#, 'CEC_F4', 'CEC_F5', 'CEC_F6', 'CEC_F7', 'CEC_F8', 'CEC_F9', 'CEC_F10', 'CEC_F11', 'CEC_F12']
ylabel='Best'
abnormalities=[
                ' ', ' ', ' ',
                ' ', ' ', ' ',
                ' ', ' ', ' ',
                ' ', ' ', ' ',
                ]

basedir='./figs_cancer_synth/' #'./gansMIASSmall/'
ad=basedir+'AD/' #'all_architectural_distortion_augmented/'

basedir='./gansMIASSmall/'
asy=basedir+'all_asymetry_augmented/'
calc=basedir+'all_calcifications_augmented/'
ms=basedir+'all_mass_augmented/'
samples= [
          ad+'AD_avt_23.png', ad+'AD_avt_24.png', ad+'AD_avt_25.png',
          asy+'ASYM_25.png', asy+'ASYM_26.png', asy+'ASYM_27.png',
          calc+'CALC_642.png', calc+'CALC_840.png', calc+'CALC_842.png',
          ms+'CIRC_1973.png', ms+'CIRC_2153.png', ms+'CIRC_2204.png'
         ]
cols=3
rows=4
fig, axs = plt.subplots(rows, cols, figsize=(10,10))
fig.subplots_adjust(wspace=-0.5, hspace=0.1)
n=0
idx=0
for i in range(rows):
    for j in range(cols): #color.BOLD+    +color.END
        axs[i, j].set_title(abnormalities[idx])
        n+=1
        img= samples[idx]
        img=cv2.imread(img)
        axs[i, j].imshow(img)        
        axs[i, j].spines['right'].set_visible(False)
        axs[i, j].spines['top'].set_visible(False)
        axs[i, j].spines['left'].set_visible(False)
        axs[i, j].spines['bottom'].set_visible(False)
        axs[i, j].set_xticks([])
        axs[i, j].set_yticks([])
        idx+=1