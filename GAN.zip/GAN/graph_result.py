# -*- coding: utf-8 -*-
"""
Created on Mon May 17 02:17:20 2021

@author: Oyelade
"""
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot
plt.style.use('classic')
    
result_dir='./Results/'
malignTypes=['MS']#,'AD', 'MS', 'CALC', 'ASY']
for i in range(len(malignTypes)):
    cond =malignTypes[i]
    fo=open(result_dir+cond+'/'+cond+'.txt')
    lines=fo.readlines()
    iterations=len(lines)
    print(str(iterations))
    '''
    start_point=0
    if cond == 'AD' or cond == 'MS':
        start_point=20000
        iterations-=start_point
    elif cond == 'CALC':
        start_point=7000
        iterations-=start_point
    print(str(iterations))
    '''
    gLossDLoss=np.zeros((iterations,iterations), dtype=np.float64)
    true_acc=np.zeros(iterations, dtype=np.float64)
    fake_acc=np.zeros(iterations, dtype=np.float64)
    tot_acc=np.zeros(iterations, dtype=np.float64)     
    n=0
    for row in lines:
        #sample line:Epoch 1 Gen Loss 0.5913612 Disc Loss: 1.5268687 True accuracy 34.375 Fake accuracy: 93.75 Total accuracy: 64.0625
        row=row.split(' ') #row[1]=epochNo, row[]
        gLossDLoss[n, 0]=float(row[4]) #genLoss
        gLossDLoss[n, 1]=float(row[7]) #dLoss
        true_acc[n]=float(row[10])
        fake_acc[n]=float(row[13])
        tot_acc[n]=float(row[16])
        #print(str(gLossDLoss[n, 0])+" - "+str(gLossDLoss[n, 1])+" - "+str(true_acc[n])+" - "+str(fake_acc[n])+" - "+str(tot_acc[n]))
        n=n+1    
        if n > iterations-1:
            break
    #print(str(len(gLossDLoss[:,0])))
    #print(str(len(gLossDLoss[:,1])))
    N = iterations
    plt.figure()
    plt.plot(np.arange(0, N), gLossDLoss[:,0], label='GenLoss')
    plt.plot(np.arange(0, N), gLossDLoss[:,1], label='DiscLoss')
    plt.title(cond+": Training Loss on Gen/Disc")
    plt.xlabel("Epoch #")
    plt.ylabel("Loss")
    plt.legend(loc="lower left")
    plt.show()
    
    # Plot the accuracy values:
    fig = plt.figure()
    plt.plot(np.arange(0, N), true_acc, label="True Accuracy")
    plt.plot(np.arange(0, N), fake_acc, label="Fake Accuracy")
    plt.grid(True)
    plt.xlabel("Epoch #")
    plt.ylabel("Accuracy")
    plt.legend(loc="lower left")
    plt.show()
    
    fig = plt.figure()
    plt.plot(np.arange(0, N), tot_acc, label="Total Accuracy")
    plt.grid(True)
    plt.xlabel("Epoch #")
    plt.ylabel("Accuracy")
    plt.legend(loc="lower left")
    plt.show()
    
    
    
    '''
    N=testIterations
    indexes = range(N)[::number_of_images_to_show_test]
    image_array = np.zeros((SAVE_IMG_WIDTH*len(indexes), number_of_images_to_show_test*SAVE_IMG_WIDTH))
    for i, e in enumerate(indexes):
        image_set = synth_images[e]
        for j in range(number_of_images_to_show_test):
            index = np.random.randint(len(image_set))
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH].shape
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH] = image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT)
            subplot = pyplot.subplot(3, 3, 1+j)  #, 1+j
            pyplot.axis('off')
            pyplot.imshow(image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT), cmap="Greys", interpolation="none")
    pyplot.show()
    '''
    

