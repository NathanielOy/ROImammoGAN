#import matplotlib
#matplotlib.use('Agg')
import tensorflow as tf
from numpy import expand_dims
from numpy import zeros
from numpy import ones
from numpy.random import randn
from numpy.random import randint

from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot
import tensorflow.contrib.slim as slim
import os
import scipy.misc
import scipy
import latest_readMammograms2
import random
import cv2
import skimage.transform
import sklearn.preprocessing
import helper2
import pdb
import csv
from numpy.random import choice
import argparse
import re


# example of smoothing class=1 to [0.7, 1.2]
def smooth_positive_labels(y):
	return y - 0.3 + (random(y.shape) * 0.5)
 
# randomly flip some labels
def noisy_labels(y, p_flip=0.05):  # flip labels with 5% probability
	# determine the number of labels to flip
	n_select = int(p_flip * y.shape[0])
	# choose labels to flip
	flip_ix = choice([i for i in range(y.shape[0])], size=n_select)
	# invert the labels in place
	y[flip_ix] = 1 - y[flip_ix]
	return y


def model_loss(input_real, input_z, out_channel_dim, alpha=0.2, smooth_factor=0.1): 
    d_model_real, d_logits_real = discriminator(input_real, alpha=alpha)

    d_loss_real = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_real,
                                                labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))

    input_fake = generator(input_z, out_channel_dim, alpha=alpha)
    d_model_fake, d_logits_fake = discriminator(input_fake, reuse=True, alpha=alpha)
    
    d_loss_fake = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake, labels=tf.zeros_like(d_model_fake)))
    
    g_loss = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake, labels=tf.ones_like(d_model_fake)))
    return d_loss_real + d_loss_fake, g_loss

#tests.test_model_loss(model_loss)
def model_inputs(image_width, image_height, image_channels, z_dim):
    """
    Create the model inputs
    :param image_width: The input image width
    :param image_height: The input image height
    :param image_channels: The number of image channels
    :param z_dim: The dimension of Z
    :return: Tuple of (tensor of real input images, tensor of z data, learning rate)
    """
    real_input_images = tf.placeholder(tf.float32, [None, image_width, image_height, image_channels], 'real_input_images')
    input_z = tf.placeholder(tf.float32, [None, z_dim], 'input_z')
    learning_rate = tf.placeholder(tf.float32, [], 'learning_rate')
    return real_input_images, input_z, learning_rate

# summarize 
def model_summary():
    model_vars = tf.trainable_variables()
    slim.model_analyzer.analyze_vars(model_vars, print_info=True)

# Define generator network
def generator(z):
    zP = slim.fully_connected(z,4*4*512,normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,scope='g_project',weights_initializer=initializer)
    zCon = tf.reshape(zP,[-1,4,4,512])
    #zP = slim.fully_connected(z,8*8*256,normalizer_fn=slim.batch_norm, activation_fn=tf.nn.relu,scope='g_project',weights_initializer=initializer)
    #zCon = tf.reshape(zP,[-1,8,8,256])

    gen1 = slim.convolution2d_transpose(zCon,num_outputs=1024,kernel_size=[5,5], #64, 512, 1024
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv1', weights_initializer=initializer)

    gen2 = slim.convolution2d_transpose(gen1,num_outputs=512,kernel_size=[5,5], #32, 256, 512
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv2', weights_initializer=initializer)

    gen3 = slim.convolution2d_transpose(gen2,num_outputs=256,kernel_size=[5,5], #16,  128, 256
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv3', weights_initializer=initializer)
    
    gen4 = slim.convolution2d_transpose(gen3,num_outputs=128,kernel_size=[5,5], #8,  64, 128
        stride=[2,2],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv4', weights_initializer=initializer)
    
    gen5 = slim.convolution2d_transpose(gen4,num_outputs=64,kernel_size=[5,5],
        stride=[1,1],padding="SAME",normalizer_fn=slim.batch_norm,activation_fn=tf.nn.relu,
        scope='g_conv5', weights_initializer=initializer)
    
    g_out = slim.convolution2d_transpose(gen5,num_outputs=1,kernel_size=[32, 32],
        padding="SAME",biases_initializer=None,activation_fn=tf.nn.tanh,scope='g_conv_out',
        weights_initializer=initializer)

    return g_out

# Define descriminator network
def discriminator(bottom, reuse=False):

    dis1 = slim.convolution2d(bottom,64,[5,5],stride=[2,2],padding="SAME", #16,  64
        biases_initializer=None,activation_fn=helper2.lrelu,reuse=reuse,scope='d_conv1',
        weights_initializer=initializer)

    dis2 = slim.convolution2d(dis1,128,[5,5],stride=[2,2],padding="SAME", #32,  128
        normalizer_fn=slim.batch_norm,activation_fn=helper2.lrelu,reuse=reuse,scope='d_conv2',
        weights_initializer=initializer)

    dis3 = slim.convolution2d(dis2,256,[5,5],stride=[2,2],padding="SAME", #64,  256
        normalizer_fn=slim.batch_norm,activation_fn=helper2.lrelu,reuse=reuse,scope='d_conv3',
        weights_initializer=initializer)
    
    dis4 = slim.convolution2d(dis3,512,[5,5],stride=[1,1],padding="SAME",  #32,  512
          normalizer_fn=slim.batch_norm,activation_fn=helper2.lrelu,reuse=reuse,scope='d_conv4',
          weights_initializer=initializer)
    
    dis5 = slim.convolution2d(dis4,1024,[5,5],stride=[1,1],padding="SAME", #16,  1024
          normalizer_fn=slim.batch_norm,activation_fn=helper2.lrelu,reuse=reuse,scope='d_conv5',
          weights_initializer=initializer)
   
    out=slim.flatten(dis5)
    d_out = slim.fully_connected(out,1,activation_fn=tf.nn.sigmoid,
    reuse=reuse,scope='d_conv_out', weights_initializer=initializer)
    
    
    return d_out, out

#######################################################################################33333
    #BEGIN Train settings and running
#########################################################################################
learning_rateG=0.00001  #1e-2  0.00025  //first learning_rateG as at epoch 5200=0.00001
learning_rateD=0.00004  #0.0025         //first learning_rateD as at epoch 5200=0.00004
betaG=0.5 #0.45
betaD=0.5 #0.45
beta2G=0.999
beta2D=0.999
epsilon=1e-08

fixed_batch_size=32
superdir='/content/gdrive/My Drive/GanExperiments/'#'../data/' #'../data/' #'/content/gdrive/My Drive/GanExperiments/' #'./'#
dataset='gansMIASSmall'  #Inbreast, gansMIASLarge,  gansMIASSmall, gansDDSM  
IMG_WIDTH=256 #32, 299 1024  2560  
IMG_HEIGHT=256  #32, 299  1024 3328


RESIZE_IMG_WIDTH=64 #32, 299 1024  2560  
RESIZE_IMG_HEIGHT=64 

SAVE_IMG_WIDTH=494 #52, 32, 299 1024  2560
SAVE_IMG_HEIGHT=494  #52, 32, 299  1024 3328

#MIAS(small and large) ['MS', 'CALC', 'ARCH', 'ASYM', 'NORM', 'B', 'M', 'CIRC', 'SPIC', 'MISC']
#DDSM labels ['MS', 'CALC', 'AD', 'ASY', 'N', 'B', 'M'] 
#["MS", "CALC", "AD", "ASY", 'N', 'B', 'M']
malignTypes=["ARCH"] #, "CALC", "AD", "ASY", "N", 'B', 'M']
iterations = 50000 # 5000, Total number of iterations to use.
testIterations=1000 #1000

z_size = 100 #Size of z vector used for generator.
alpha=0.2
smooth_factor=0.1
history=np.zeros((iterations,iterations), dtype=np.float64)
images   = []
synth_images   = []
true_acc = np.zeros(iterations, dtype=np.float64)
fake_acc = np.zeros(iterations, dtype=np.float64)
tot_acc  = np.zeros(iterations, dtype=np.float64)


#images during training
number_of_images_to_show_train=9
#images already synthesis  
number_of_images_to_show_test=9

for i in range(len(malignTypes)):
    print("Loading in Mammogram data...")
    mgrams = latest_readMammograms2.readData(1, IMG_WIDTH)
    mgram_data = mgrams.data
    mgram_labels = mgrams.labels
    print("Mammogram data loaded.\n")

    # Connecting generator and discriminator networks
    tf.reset_default_graph()
    
    #This initializaer is used to initialize all the weights of the network.
    #initializer = tf.contrib.layers.variance_scaling_initializer(dtype=tf.float32) #He initializer
    initializer = tf.truncated_normal_initializer(stddev=0.02)
    #These two placeholders are used for input into the generator and discriminator, respectively.
    z_in = tf.placeholder(shape=[None,z_size],dtype=tf.float32) #Random vector
    real_in = tf.placeholder(shape=[None,RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT,1],dtype=tf.float32) #Real images
    
    Gz = generator(z_in) #Generates images from random z vectors
    Dx, d_model_real = discriminator(real_in) #Produces probabilities for real images
    Dg, d_model_fake = discriminator(Gz,reuse=True) #Produces probabilities for generator images

    # ## Discriminator and Generator Losses
    # 
    # Now we need to calculate the losses, which is a little tricky. For the discriminator, the total loss is the sum of the losses for real and fake images, `d_loss = d_loss_real + d_loss_fake`. The losses will by sigmoid cross-entropys, which we can get with `tf.nn.sigmoid_cross_entropy_with_logits`. We'll also wrap that in `tf.reduce_mean` to get the mean for all the images in the batch. So the losses will look something like 
    # 
    # ```python
    # tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=logits, labels=labels))
    # ```
    # 
    # For the real image logits, we'll use `d_logits_real` which we got from the discriminator in the cell above. For the labels, we want them to be all ones, since these are all real images. To help the discriminator generalize better, the labels are reduced a bit from 1.0 to 0.9, for example,  using the parameter `smooth`. This is known as label smoothing, typically used with classifiers to improve performance. In TensorFlow, it looks something like `labels = tf.ones_like(tensor) * (1 - smooth)`
    # 
    # The discriminator loss for the fake data is similar. The logits are `d_logits_fake`, which we got from passing the generator output to the discriminator. These fake logits are used with labels of all zeros. Remember that we want the discriminator to output 1 for real images and 0 for fake images, so we need to set up the losses to reflect that.
    # 
    # Finally, the generator losses are using `d_logits_fake`, the fake image logits. But, now the labels are all ones. The generator is trying to fool the discriminator, so it wants to discriminator to output ones for fake images.
    d_loss_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_model_real,labels=tf.ones_like(d_model_real) * (1 - smooth_factor)))
    d_loss_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_model_fake, labels=tf.zeros_like(d_model_fake)))
    d_loss = d_loss_real + d_loss_fake
    g_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_model_fake, labels=tf.ones_like(d_model_fake)))
    
    #These functions together define the optimization objective of the GAN.
    #d_loss = -tf.reduce_mean(tf.log(Dx) + tf.log(1.-Dg)) #This optimizes the discriminator.
    #g_loss = -tf.reduce_mean(tf.log(Dg)) #This optimizes the generator.
    
    # Compute the discriminator accuracy on real data, fake data, and total:
    accuracy_real  = tf.reduce_mean(tf.cast(tf.equal(tf.round(Dx), tf.ones_like(Dx)), tf.float32))
    accuracy_fake  = tf.reduce_mean(tf.cast(tf.equal(tf.round(Dg), tf.zeros_like(Dg)), tf.float32))
    total_accuracy = 0.5*(accuracy_fake +  accuracy_real)
    
    tvars = tf.trainable_variables()
    #The below code is responsible for applying gradient descent to update the GAN.
    g_vars = [var for var in tvars if var.name.startswith('g_conv')]
    d_vars = [var for var in tvars if var.name.startswith('d_conv')]
    trainerD = tf.train.AdamOptimizer(learning_rate=learning_rateD,beta1=betaD, beta2=beta2D, epsilon=epsilon).minimize(d_loss, var_list=d_vars)
    trainerG = tf.train.AdamOptimizer(learning_rate=learning_rateG,beta1=betaG, beta2=beta2G, epsilon=epsilon).minimize(g_loss, var_list=g_vars)
    
    
    '''
    trainerD = tf.train.AdamOptimizer(learning_rate=learning_rateD,beta1=betaD, beta2=beta2D, epsilon=epsilon)
    trainerG = tf.train.AdamOptimizer(learning_rate=learning_rateG,beta1=betaG, beta2=beta2G, epsilon=epsilon)
    d_grads = trainerD.compute_gradients(d_loss,g_vars) #Only update the weights for the discriminator network.
    g_grads = trainerG.compute_gradients(g_loss,d_vars) #Only update the weights for the generator network.
    update_D = trainerD.apply_gradients(d_grads)
    update_G = trainerG.apply_gradients(g_grads)
    '''
    
    # Start training loop
    batch_size =0  # Size of image batch to apply at each iteration of categories of abnormalities.
    if (len(mgram_data) < fixed_batch_size):
        batch_size =len(mgram_data)
    else:
        batch_size =fixed_batch_size
    
    steps=len(mgram_data)//batch_size
   
    #"N",  "B", "AD", "ASY", "MS", "CALC"
    #https://colab.research.google.com/notebooks/io.ipynb#scrollTo=XDg9OBaYqRMd
    # Which condition to use: N = normal, B = benign, M = malignant, AD=architectural distortion, ASY=asymetry, MS=mass, CALC=calcification
    cond =malignTypes[i] #'MS' 
    
    if cond == "N" or cond == "NORM": # 'NORM',
        cond='N'
    elif cond == "AD" or cond == "ARCH": #'ARCH'
        cond='AD'
    elif cond == "ASY" or cond == "ASYM": #'ASYM', 'NORM',
        cond='ASY'
    else:
        cond=cond
    
    #superdir='./'
    synth_sample_directory = superdir+'figs_cancer_synth/'+cond #Directory to save sample images from generator in.
    model_directory2 = superdir+'models_cancer' #Directory to load trained model from.
    sample_directory = superdir+'figs_cancer2/'+dataset+'/'+cond # Directory to save sample images from generator in.
    model_directory = superdir+'models_cancer2/'+dataset+'/'+cond+'/' # Directory to save trained model to.
        
    init = tf.global_variables_initializer()
    saver = tf.train.Saver(max_to_keep=3)
    with tf.Session(config=tf.ConfigProto(log_device_placement=True)) as sess:
        '''        
        parser = argparse.ArgumentParser()
        parser.add_argument('checkpoint')#
        args = parser.parse_args()
        http://www.da.inf.ethz.ch/teaching/2018/DeepLearning/material/mnist-gan.py
        '''
        number_of_epoch_to_checkpoint=50
        start_epoch = 0
        start_step = 0
        checkpoint='checkpoint'
        num_checkpoint=44251
        if checkpoint=='checkpoint':
            #ckpt = tf.train.get_checkpoint_state(model_directory) latest_checkpoint 4901, 1676
            ckpt = tf.train.import_meta_graph(model_directory+'model-'+str(num_checkpoint)+'.cptk.meta')
            ckpt2 =tf.train.latest_checkpoint(model_directory+'/')
            print(ckpt2)
            saver.restore(sess,ckpt2)  #ckpt2.model_checkpoint_path
            found_num = re.search(r'\d+', checkpoint)
            if num_checkpoint:
                checkpoint_id = int(num_checkpoint)  #int(found_num.group(0))
                #start_epoch = checkpoint_id // iterations
                start_epoch = checkpoint_id % iterations
                print('Found latest checkpoint of '+str(start_epoch)+' starting from '+str(start_step))

        sess.run(init)
        print("Training start")
        
        with open(sample_directory+'/result.csv', 'w', newline ='') as allcsvfile:
                writer = csv.writer(allcsvfile, delimiter=',')
                
                for i in range(start_epoch, iterations): #range(iterations)
                    for ii in range(len(mgram_data)//batch_size):
                        
                        #Sample random noise for G or Generate a random z batch
                        zs = np.random.uniform(-1.0,1.0,size=[batch_size,z_size]).astype(np.float32) 
                        
                        # Get images, reshape and rescale to pass to D
                        xs,_ = helper2.next_batch_cond(batch_size, mgram_data, mgram_labels, cond,IMG_WIDTH, IMG_HEIGHT, dataset, i)
                        #xs=cv2.resize(xs, (RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT), interpolation=cv2.INTER_CUBIC)
                        xs=np.resize(xs, (1, RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT, batch_size))
                        xs = (np.reshape(xs,[batch_size,RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT,1]) - 0.5) * 2.0 #Transform it to be between -1 and 1
                        
                        #batch_images = batch[0].reshape((batch_size, 784))
                        #batch_images = batch_images*2 - 1
                        # Sample random noise for G   batch_z = np.random.uniform(-1, 1, size=(batch_size, z_size))
                        
                        # Run optimizers
                        _ = sess.run(trainerD, feed_dict={real_in: xs, z_in: zs})
                        _ = sess.run(trainerG, feed_dict={z_in: zs})
            
                    
                    dLoss = sess.run(d_loss,{z_in:zs,real_in:xs}) #Update the discriminator
                    gLoss = g_loss.eval({z_in: zs}) #sess.run([update_G,g_loss],feed_dict={z_in:zs}) #Update the generator, twice for good measure.
                    #_,gLoss = sess.run([update_G,g_loss],feed_dict={z_in:zs})
                    
                    [acc_fake, acc_real, acc] = sess.run([accuracy_fake, accuracy_real, total_accuracy],
                      feed_dict={z_in:zs,real_in:xs})
                    
                    if i % 1 == 0:
                        history[i, 0]=gLoss
                        history[i, 1]=dLoss
                        
                        true_acc[i]=acc_real*100
                        fake_acc[i]=acc_fake*100
                        tot_acc[i]=acc*100
                                
                        z2 = np.random.uniform(-1.0,1.0,size=[batch_size,z_size]).astype(np.float32) #Generate another z batch
                        newZ = sess.run(Gz,feed_dict={z_in:z2}) #Use new z to get sample images from generator.

                        newZ_filt = helper2.filt(newZ[0],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT)
                        if not os.path.exists(sample_directory):
                            os.makedirs(sample_directory)
                        #Save sample generator images for viewing training progress.
                        #newZint = interpolate(newZ[0])
                        newZ_filt=np.resize(newZ_filt, (SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT))
                            
                        if i % 100 == 0 and i != 0:                              
                            helper2.save_images(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]),[1,1],sample_directory+'/'+cond+'_'+str(i)+'.png')    
                            for i_j in range(int(9)):
                                subplot = pyplot.subplot(3, 3, 1+i_j)
                                pyplot.axis('on')
                                pyplot.imshow(helper2.filt(newZ[i_j],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT),
                                              cmap="Greys", interpolation="none")
                            
                            #pyplot.imshow(newZ_filt, cmap="Greys", interpolation="none")
                            pyplot.show()
                        #images.append(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))
                        fieldvalues = [history[i, 0], history[i, 1], true_acc[i], fake_acc[i], tot_acc[i]] 
                        writer.writerow(fieldvalues)
                        #writer.flush()
                        
                        epoch_log="Epoch "+str(i+1)+" "+"Gen Loss " + str(gLoss) + " Disc Loss: " + str(dLoss) +" True accuracy " + str(true_acc[i]) + " Fake accuracy: " + str(fake_acc[i])+ " Total accuracy: " + str(tot_acc[i])+"\n"
                        with open(sample_directory+'/result.txt', 'a') as f:
                            f.write(epoch_log)
                            f.flush()
                            
                        print(epoch_log)
                    
                    
                    if i % number_of_epoch_to_checkpoint == 0 and i != 0:
                        if not os.path.exists(model_directory):
                            os.makedirs(model_directory)
                        saver.save(sess,model_directory+'/model-'+str((i+1))+'.cptk')
                    
    
    # model_summary()
    
    '''
    This is important. A stable GAN will have a discriminator loss around 0.5, typically between 0.5 and maybe as high as 0.7 or 0.8. The generator loss is typically higher and may hover around 1.0, 1.5, 2.0, or even higher.
    The accuracy of the discriminator on both real and generated (fake) images will not be 50%, but should typically hover around 70% to 80%.
    '''
    
    # Loading previous network to generate additional images
    e_fake_acc = np.zeros(testIterations, dtype=np.float64)
    batch_size_sample = 16
    path =model_directory  #'./models_cancer/'
    init = tf.global_variables_initializer()
    saver = tf.train.Saver()
    with tf.Session(config=tf.ConfigProto(log_device_placement=True)) as sess:
        sess.run(init)
        #Reload the model.
        print('Loading Model...')
        ckpt = tf.train.get_checkpoint_state(path)
        #saver.restore(sess,ckpt.model_checkpoint_path)
        
        for j in range(testIterations):
            #pdb.set_trace()
            zs = np.random.uniform(-1.0,1.0,size=[batch_size_sample,z_size]).astype(np.float32) #Generate a random z batch
            newZ = sess.run(Gz,feed_dict={z_in:zs}) #Use new z to get sample images from generator.

            newZ_filt = helper2.filt(newZ[0],RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT)
            
            [acc_fake] = sess.run([accuracy_fake],feed_dict={z_in:zs})
            
            e_fake_acc[j]=acc_fake*100
            
            if not os.path.exists(synth_sample_directory):
                os.makedirs(synth_sample_directory)
                
            newZ_filt=np.resize(newZ_filt, (SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT))
            helper2.save_images(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]),[1,1],synth_sample_directory+'/'+cond+'_'+str(j)+'.png')
            
            #synth_images.append(np.reshape(newZ_filt,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))

for i in range(len(malignTypes)):
    history=np.zeros((iterations,iterations), dtype=np.float64)
    true_acc=np.zeros(iterations, dtype=np.float64)
    fake_acc=np.zeros(iterations, dtype=np.float64)
    tot_acc=np.zeros(iterations, dtype=np.float64)
    cond =malignTypes[i]
    
    if cond == "N" or cond == "NORM": # 'NORM',
        cond='N'
    elif cond == "AD" or cond == "ARCH": #'ARCH'
        cond='AD'
    elif cond == "ASY" or cond == "ASYM": #'ASYM', 'NORM',
        cond='ASY'
    else:
        cond=cond
        
    sample_directory = superdir+'figs_cancer2/'+dataset+'/'+cond
    synth_sample_directory = superdir+'figs_cancer_synth/'+cond
    
    handle=sample_directory+'/result.csv'
    f=open(handle, newline ='')
    n=0
    for row in csv.reader(f, delimiter=','):
        history[n, 0]=float(row[0])
        history[n, 1]=float(row[1])
        true_acc[n]=float(row[2])
        fake_acc[n]=float(row[3])
        tot_acc[n]=float(row[4])
        print(str(history[n, 0])+" - "+str(history[n, 1])+" - "+str(true_acc[n])+" - "+str(fake_acc[n]))
        n+=1
    
    for indexj in range(len(e_fake_acc)):
        print("Evaluation Fake accuracy: " + str(e_fake_acc[indexj]))
        
    for idx in range(iterations):
        im=im = np.array(Image.open(sample_directory+'/'+cond+'_'+str(idx)+'.png'))
        images.append(np.reshape(im,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))
    '''
    for idx in range(testIterations):
        im=im = np.array(Image.open(synth_sample_directory))
        synth_images.append(np.reshape(im,[1,SAVE_IMG_WIDTH, SAVE_IMG_HEIGHT]))
    '''  
    N = iterations
    plt.style.use('seaborn-whitegrid')
    plt.figure()
    plt.plot(np.arange(0, N), history[0], label='GenLoss')
    plt.plot(np.arange(0, N), history[1], label='DiscLoss')
    plt.title(cond+": Training Loss on Gen/Disc")
    plt.xlabel("Epoch #")
    plt.ylabel("Loss")
    plt.legend(loc="lower left")
    plt.show()
    
    
    # Plot the accuracy values:
    fig = plt.figure()
    plt.plot(np.arange(0, N), true_acc, label="True Accuracy")
    plt.plot(np.arange(0, N), fake_acc, label="Fake Accuracy")
    plt.plot(np.arange(0, N), tot_acc, label="Total Accuracy")
    plt.grid(True)
    plt.xlabel("Epoch #")
    plt.ylabel("Accuracy")
    plt.legend(loc="lower left")
    plt.show()
    
    
    indexes = range(N)[::number_of_images_to_show_train]
    image_array = np.zeros((SAVE_IMG_WIDTH*len(indexes), number_of_images_to_show_train*SAVE_IMG_WIDTH))
    for i, e in enumerate(indexes):
        image_set = images[e]
        for j in range(number_of_images_to_show_train):
            index = np.random.randint(len(image_set))
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH].shape
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH] = image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT)
            subplot = plt.subplot(3, 3, 1+j)  #
            plt.axis('off')
            #subplot.set_title(cond, fontsize=12) 
            plt.imshow(image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT), cmap="Greys", interpolation="none")
    plt.show()
     
    
    N=testIterations
    indexes = range(N)[::number_of_images_to_show_test]
    image_array = np.zeros((SAVE_IMG_WIDTH*len(indexes), number_of_images_to_show_test*SAVE_IMG_WIDTH))
    for i, e in enumerate(indexes):
        image_set = synth_images[e]
        for j in range(number_of_images_to_show_test):
            index = np.random.randint(len(image_set))
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH].shape
            image_array[i*SAVE_IMG_WIDTH:(i+1)*SAVE_IMG_WIDTH, j*SAVE_IMG_WIDTH:(j+1)*SAVE_IMG_WIDTH] = image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT)
            subplot = pyplot.subplot(3, 3, 1+j)  #, 1+j
            pyplot.axis('off')
            pyplot.imshow(image_set[index].reshape(SAVE_IMG_WIDTH,SAVE_IMG_HEIGHT), cmap="Greys", interpolation="none")
    pyplot.show()
    
    
'''
https://medium.com/coinmonks/celebrity-face-generation-using-gans-tensorflow-implementation-eaa2001eef86
gen_cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=disc_fake,
                                                                                      labels=tf.ones_like(
                                                                                          disc_fake)))
                    disc_cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=disc_fake,
                                                                                       labels=tf.zeros_like(
                                                                                           disc_fake)))
                    disc_cost += tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=disc_real,
                                                                                        labels=tf.ones_like(




 # Read images from file.
    im1 = tf.decode_png('path/to/im1.png')
    im2 = tf.decode_png('path/to/im2.png')
    # Compute SSIM over tf.uint8 Tensors.
    ssim1 = tf.image.ssim(im1, im2, max_val=255, filter_size=11,
                          filter_sigma=1.5, k1=0.01, k2=0.03)

    # Compute SSIM over tf.float32 Tensors.
    im1 = tf.image.convert_image_dtype(im1, tf.float32)
    im2 = tf.image.convert_image_dtype(im2, tf.float32)
    ssim2 = tf.image.ssim(im1, im2, max_val=1.0, filter_size=11,
                          filter_sigma=1.5, k1=0.01, k2=0.03)
    # ssim1 and ssim2 both have type tf.float32 and are almost equal.


Returns:
A tensor containing an SSIM value for each image in batch. Returned SSIM values are in range (-1, 1], when pixel values are non-negative. Returns a tensor with shape: broadcast(img1.shape[:-3], img2.shape[:-3]).




mse = tf.keras.losses.MeanSquaredError()
loss = mse([0., 0., 1., 1.], [1., 1., 1., 0.])
print('Loss: ', loss.numpy())  # Loss: 0.75                                                                                            disc_real)))
'''


