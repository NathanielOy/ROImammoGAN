# -*- coding: utf-8 -*-
"""
Created on Sun Oct  3 15:12:54 2021

@author: Oyelade
"""
import os
import numpy as np
import matplotlib.pyplot as plt
import cv2
import tensorflow as tf
from skimage.transform import resize
import glob
import imageio

# Display two images
def display(a, b, title1 = "Original", title2 = "Edited"):
    plt.subplot(121), plt.imshow(a), plt.title(title1)
    plt.xticks([]), plt.yticks([])
    plt.subplot(122), plt.imshow(b), plt.title(title2)
    plt.xticks([]), plt.yticks([])
    plt.show()

# Denoise
def processing(path):
    imgformat = ['.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif']
    data = sorted([os.path.join(path, file)
                          for file in os.listdir(path)
                          if file.endswith(tuple(imgformat))])
    # Reading all images to work
    img = [cv2.imread(i) for i in data]  
        
    # Remove noise
    # Using Gaussian Blur
    no_noise = []
    for i in range(len(img)):
        blur = cv2.fastNlMeansDenoisingColored(img[i],None,10,10,7,21) #GaussianBlur(img[i], (5, 5), 0)#.astype('uint8')
        display(img[i], blur, 'Original', 'Blured: No Noise')
        no_noise.append(blur)

def main():
    processing('./figs_cancer_synth/samples/')

main()    
