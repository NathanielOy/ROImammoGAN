# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 14:11:51 2020

@author: Oyelade

ARCH
data_1 = [[27.97, 28.00, 27.94, 27.83, 27.98, 28.00, 27.93, 27.99, 28.02, 28.04]]  
data_2 = [[0.04, 0.04, 0.04, 0.03, 0.04, 0.05, 0.05, 0.04, 0.06, 0.05]]
data_3 = [[0.48, 0.48, 0.48, 0.48, 0.48, 0.48, 0.47, 0.48, 0.47, 0.47]] 
data_4 = [[0.90, 0.88, 0.89, 0.89, 0.89, 0.88, 0.87, 0.87, 0.90, 0.87]] 
data_5 = [[27.05, 17.79, 29.11, 15.33, 28.32, 16.62, 34.25, 34.27, 18.04, 37.61]] 
data_6 = [[22.65, 23.17, 23.04, 22.70, 23.67, 23.71, 24.23, 23.26, 23.01, 24.91]] 
data_7 = [[25.81, 37.07, 30.40, 28.10, 25.31, 27.50, 22.30, 27.56, 27.48, 24.45]] 

ASY
data_1 = [[27.60, 27.68, 27.25, 27.72, 27.67, 27.38, 28.72, 27.51, 27.65, 27.70]]  
data_2 = [[0.74, 0.71, 0.77, 0.80, 0.73, 0.73, 0.66, 0.75, 0.75, 0.79]]
data_3 = [[0.13, 0.15, 0.11, 0.10, 0.14, 0.13, 0.17, 0.13, 0.13, 0.11]] 
data_4 = [[0.77, 0.79, 0.80, 0.76, 0.75, 0.81, 0.83, 0.74, 0.75, 0.77]] 
data_5 = [[128.64, 99.24, 106.95, 122.02, 126.44, 126.58, 101.89, 113.56, 125.46, 105.03]] 
data_6 = [[59.77, 62.88, 61.86, 62.92, 59.49, 62.47, 57.70, 62.98, 58.68, 61.94]] 
data_7 = [[53.52, 53.10, 70.46, 64.81, 54.14, 54.82, 46.08, 50.48, 80.70, 58.10]] 


CALC
data_1 = [[27.74, 28.11, 27.75, 27.79, 27.67, 27.87, 28.36, 27.79, 28.43, 27.84]]  
data_2 = [[0.05, 0.05, 0.05, 0.03, 0.05, 0.05, 0.05, 0.05, 0.05, 0.06]]
data_3 = [[0.48, 0.47, 0.47, 0.48, 0.47, 0.48, 0.48, 0.47, 0.47, 0.47]] 
data_4 = [[0.84, 0.86, 0.89, 0.87, 0.85, 0.89, 0.78, 0.86, 0.79, 0.90]] 
data_5 = [[18.63, 21.52, 22.43, 32.13, 17.46, 10.95, 13.00, 20.40, 22.52, 24.81]] 
data_6 = [[19.56, 16.54, 12.99, 20.36, 14.22, 15.37, 15.14, 15.44, 13.48, 20.36]] 
data_7 = [[34.02, 44.94, 33.25, 38.35, 32.89, 24.84, 25.14, 31.20, 37.85, 29.34]] 

MS
data_1 = [[7.61,	10.36,	10.53,	8.97,	8.34,	8.37,	8.54,	5.21,	4.11,	10.54]]  
data_2 = [[0.35,	0.38,	0.39,	0.37,	0.36,	0.36,	0.36,	0.30,	0.25,	0.39]]
data_3 = [[0.33, 0.31, 0.31, 0.32, 0.32, 0.32, 0.32, 0.35, 0.38, 0.31]] 
data_4 = [[0.84,	0.80,	0.84,	0.83,	0.87,	0.83,	0.87,	0.90,	0.88,	0.87]] 
data_5 = [[52.10,	52.10,	69.52,	52.10,	52.10,	52.10,	52.10,	52.10,	52.10,	69.52]] 
data_6 = [[69.89,	69.89,	69.96,	69.89,	69.89,	69.89,	69.89,	69.89,	69.89,	69.96]] 
data_7 = [[150.22,	150.22,	122.82,	150.22,	150.22,	150.22,	150.22,	150.22,	150.22,	122.82]] 
"""

# Import libraries 
import matplotlib.pyplot as plt 
import numpy as np 
import seaborn as sns
sns.set() # Setting seaborn as default style even if use only matplotlib


# Creating dataset 
hybrids1=['PSNR', 'SSIM', 'DSSIM', 'FSIM', 'BRISQUE2',	'PQUE',	'NIQE']

data_1 = [[27.60, 27.68, 27.25, 27.72, 27.67, 27.38, 28.72, 27.51, 27.65, 27.70]]  
data_2 = [[0.74, 0.71, 0.77, 0.80, 0.73, 0.73, 0.66, 0.75, 0.75, 0.79]]
data_3 = [[0.13, 0.15, 0.11, 0.10, 0.14, 0.13, 0.17, 0.13, 0.13, 0.11]] 
data_4 = [[0.77, 0.79, 0.80, 0.76, 0.75, 0.81, 0.83, 0.74, 0.75, 0.77]] 
data_5 = [[128.64, 99.24, 106.95, 122.02, 126.44, 126.58, 101.89, 113.56, 125.46, 105.03]] 
data_6 = [[59.77, 62.88, 61.86, 62.92, 59.49, 62.47, 57.70, 62.98, 58.68, 61.94]] 
data_7 = [[53.52, 53.10, 70.46, 64.81, 54.14, 54.82, 46.08, 50.48, 80.70, 58.10]] 


data1 = [data_1, data_2, data_3, data_4, data_5, data_6, data_7] 
colors = ['yellow', '#8B2500']
colors_c1 = dict(color=colors[0])
colors_c2 = dict(color=colors[1])
box_colors = ['blue', 'red']    

plt.style.use('seaborn-white')
fig, axs = plt.subplots()
fig.subplots_adjust(hspace=1.9)
#fig.tight_layout(pad=3.9, h_pad=1.0, w_pad=1.0)


bp=axs.boxplot(data1[0][0], positions=[1], labels=[hybrids1[0]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])

'''
bp=axs.boxplot(data1[1][0], positions=[2], labels=[hybrids1[1]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])
'''
#bp=axs.boxplot(data1[2][0], positions=[3], labels=[hybrids1[2]], boxprops=colors_c2, medianprops=colors_c2, 
#        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
#plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])

'''
bp=axs.boxplot(data1[3][0], positions=[4], labels=[hybrids1[3]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])
'''

'''
bp=axs.boxplot(data1[4][0], positions=[5], labels=[hybrids1[4]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])
bp=axs.boxplot(data1[5][0], positions=[6], labels=[hybrids1[5]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])
bp=axs.boxplot(data1[6][0], positions=[7], labels=[hybrids1[6]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], linewidth=2, color=box_colors[0])
'''
axs.set(xlabel='', ylabel='values')
plt.show() 


'''
A figure with just one subplot

subplots() without arguments returns a Figure and a single Axes.

This is actually the simplest and recommended way of creating a single Figure and Axes.

fig, ax = plt.subplots()
ax.plot(x, y)
ax.set_title('A single plot')



Stacking subplots in one direction

The first two optional arguments of pyplot.subplots define the number of rows and columns of the subplot grid.

When stacking in one direction only, the returned axs is a 1D numpy array containing the list of created Axes.

fig, axs = plt.subplots(2)
fig.suptitle('Vertically stacked subplots')
axs[0].plot(x, y)
axs[1].plot(x, -y)



To obtain side-by-side subplots, pass parameters 1, 2 for one row and two columns.

fig, (ax1, ax2) = plt.subplots(1, 2)
fig.suptitle('Horizontally stacked subplots')
ax1.plot(x, y)
ax2.plot(x, -y)


You can use tuple-unpacking also in 2D to assign all subplots to dedicated variables:

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
fig.suptitle('Sharing x per column, y per row')
ax1.plot(x, y)
ax2.plot(x, y**2, 'tab:orange')
ax3.plot(x, -y, 'tab:green')
ax4.plot(x, -y**2, 'tab:red')

for ax in fig.get_axes():
    ax.label_outer()


https://www.webucator.com/article/python-color-constants-module/
https://matplotlib.org/3.1.0/gallery/subplots_axes_and_figures/subplots_demo.html
'''