          ========================
==========Practices in GAN triaing=====================
          =========================
====Large kernels and more filters==========
Larger kernels cover more pixels in the previous layer image and hence, can look at more information. 
5x5 kernels worked well with CIFAR-10, Using 3x3 kernels in discriminator caused the discriminator loss to rapidly 
approach 0.

=====Flip labels (Generated=True, Real=False)====
Although it seems silly at first, one major trick that worked for me was to change label assignments.
If you are using Real Images = 1 and Generated Images = 0, it helps to have it the other way around. 

====Batch norm helps, but only if you have other things in place====
Batch normalization definitely helps the final result. Adding Batch norm resulted in distinctly sharper generated images.

====One class at a time======
In order to make it easier to train GANs, it is useful to ensure the input data has similar characteristics. 
For example, instead of training a GAN on all 10 classes of CIFAR-10, it is better to pick one class

====No early stopping======
A silly mistake I made — probably due to my impatience — was to kill training after a few hundred mini-batches 
when I saw the losses not making any discernible progress or if the generated samples stayed noisy. 
One exception to this rule is if you see the Discriminator loss rapidly approaching 0. If that happens, 
there is almost no chance of recovery and its better to restart training, probably after changing something in the 
networks or the training process

====Use ReLU, Leaky ReLU, and Tanh====
Activation functions such as ReLU are used to address the vanishing gradient problem in deep convolutional neural 
networks and promote sparse activations (e.g. lots of zero values).
ReLU is recommended for the generator, but not for the discriminator model. Instead, a variation of ReLU that allows 
values less than zero, called Leaky ReLU, is preferred in the discriminator.

====Use Adam Optimization===
Both the generator and discriminator are trained with stochastic gradient descent with a modest batch size of 128 
images.

====Normalize inputs to the range [-1, 1] and use tanh in the generator output====

Use Gaussian Weight Initialization

Before a neural network can be trained, the model weights (parameters) must be initialized to small random variables.

The best practice for DCAGAN models reported in the paper is to initialize all weights using a zero-centered Gaussian 
distribution (the normal or bell-shaped distribution) with a standard deviation of 0.02.


Finally, we report the loss each batch. It is critical to keep an eye on the loss over batches. The reason for this 
is that a crash in the discriminator loss indicates that the generator model has started generating rubbish examples 
that the discriminator can easily discriminate.

Monitor the discriminator loss and expect it to hover around 0.5 to 0.8 per batch on this dataset. The generator 
loss is less critical and may hover between 0.5 and 2 or higher on this dataset. A clever programmer might even 
attempt to detect the crashing loss of the discriminator, halt, and then restart the training process.


Instead, images must be subjectively evaluated for quality by a human operator. This means that we cannot know when 
to stop training without looking at examples of generated images. In turn, the adversarial nature of the training 
process means that the generator is changing after every batch, meaning that once “good enough” images can be 
generated, the subjective quality of the images may then begin to vary, improve, or even degrade with subsequent 
updates.
There are three ways to handle this complex training situation.
1.	Periodically evaluate the classification accuracy of the discriminator on real and fake images.
2.	Periodically generate many images and save them to file for subjective review.
3.	Periodically save the generator model.



The following is a python implementation of a mean filter:

import numpy as np
import cv2from matplotlib 
import pyplot as pltfrom PIL 
import Image, ImageFilter
%matplotlib inlineimage = cv2.imread('AM04NES.JPG') # reads the image
image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV) # convert to HSV
figure_size = 9 # the dimension of the x and y axis of the kernal.new_image = cv2.blur(image,(figure_size, figure_size))plt.figure(figsize=(11,6))plt.subplot(121), plt.imshow(cv2.cvtColor(image, cv2.COLOR_HSV2RGB)),plt.title('Original')plt.xticks([]), plt.yticks([])plt.subplot(122), plt.imshow(cv2.cvtColor(new_image, cv2.COLOR_HSV2RGB)),plt.title('Mean filter')plt.xticks([]), plt.yticks([])plt.show()



Median Filter
The median filter calculates the median of the pixel intensities that surround the center pixel in a n x n kernel. 
The median then replaces the pixel intensity of the center pixel. The median filter does a better job of removing salt 
and pepper noise than the mean and Gaussian filters. The median filter preserves the edges of an image but it does not 
deal with speckle noise. The ‘medianBlur’ function from the Open-CV library can be used to implement a median filter.

new_image = cv2.medianBlur(image, figure_size)plt.figure(figsize=(11,6))plt.subplot(121), plt.imshow(cv2.cvtColor(image, cv2.COLOR_HSV2RGB)),plt.title('Original')plt.xticks([]), plt.yticks([])plt.subplot(122), plt.imshow(cv2.cvtColor(new_image, cv2.COLOR_HSV2RGB)),plt.title('Median Filter')plt.xticks([]), plt.yticks([])plt.show()