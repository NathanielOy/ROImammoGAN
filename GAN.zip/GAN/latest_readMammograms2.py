from PIL import Image
import csv
import numpy as np
from numpy import float32
from numpy import uint8
import random
import scipy.misc
import pdb
from matplotlib import pyplot
#from resizeimage import resizeimage

class mdata:
    def __init__(self, data, labels, n, b, m, ad, asy, ms, calc):
        self.data      = data
        self.labels    = labels
        self.normal    = n
        self.benign    = b
        self.malignant = m
        self.adistortion = ad
        self.asymetry = asy
        self.mass = ms
        self.calcification = calc

def readData(test_num, IMG_WIDTH):
    superdir='./'#'../data/' #'/content/gdrive/My Drive/GanExperiments/' #'../data/' #'/content/gdrive/My Drive/GanExperiments/'  ../data/
    dir_init=superdir+'gansMIASSmall/' #  '/gdata/gansMIASSmall/'#   ../data/gansMIASSmall/gansDDSM
    if test_num == 2:
        print("Testing all masses augmented")
        handle = dir_init+"all_mass_augmented/label_all_mass_augmented.csv"
        fname = dir_init+"all_mass_augmented/"
    elif test_num == 1:
        print("Testing all calcifications augmented")
        handle = dir_init+"all_calcifications_augmented/label_all_calcifications_augmented.csv"
        fname = dir_init+"all_calcifications_augmented/"
    elif test_num == 0:
        print("Testing all architectural distortion augmented")
        handle = dir_init+"all_architectural_distortion_augmented/label_all_architectural_distortion_augmented.csv"
        fname = dir_init+"all_architectural_distortion_augmented/"
    elif test_num == 3:
        print("Testing all asymetry augmented")
        handle = dir_init+"all_asymetry_augmented/label_all_asymetry_augmented.csv"
        fname = dir_init+"all_asymetry_augmented/"
    elif test_num == 4:
        print("Testing all normal augmented")
        handle = dir_init+"all_normal_augmented/label_all_normal_augmented.csv"
        fname = dir_init+"all_normal_augmented/"
    elif test_num == 5:
        print("Testing all benign augmented")
        handle = dir_init+"all_benign_augmented/label_all_benign_augmented.csv"
        fname = dir_init+"all_benign_augmented/"
    elif test_num == 6:
        print("Testing all malignant augmented")
        handle = dir_init+"all_malignant_augmented/label_all_malignant_augmented.csv"
        fname = dir_init+"all_malignant_augmented/"
    else:
        print("Testing all mammograms augmented")
        handle = dir_init+"all_augmented/label_augmented.csv"
        fname = dir_init+"all_augmented/"
    
    f=open(handle, newline ='')
    labels = []
    mgrams = []
    n = 0
    b = 0
    m = 0
    ad=0
    asy=0
    ms=0
    calc=0
    labelIndex=1
    fileIndex=0
    num_img_to_display=0
    data_con=[]
    
    for row in csv.reader(f, delimiter=','):
        #print(row)
    # Which condition to use: N = normal, B = benign, 
    # M = malignant, AD=architectural distortion, ASY=asymetry, MS=mass, CALC=calcification
        if row[labelIndex] == "N" or row[labelIndex] == "NORM": # 'NORM',
            n += 1
        elif row[labelIndex] == "B":
            b += 1
        elif row[labelIndex] == "AD" or row[labelIndex] == "ARCH": #'ARCH'
            ad += 1
        elif row[labelIndex] == "ASY" or row[labelIndex] == "NORM": #'ASYM', 'NORM',
            asy += 1
        elif row[labelIndex] == "MS":
            ms += 1
        elif row[labelIndex] == "CALC":
            calc += 1
        
        labels.append(row[labelIndex])
        
        if row[labelIndex] != "N" and row[labelIndex] != "B":#malignant
            m += 1
            
        #read image pixel vals in
        name = row[fileIndex]
        name = fname + name #.../mdbXYZ.png
        # print("Reading in: ", name)
        # for i in range(1,num_images):
        #     if i < 33 or i > 57 or i < 291 or i > 311: #ignored
        #         if i < 100:
        #             if i < 10:
        #                 name = fname + "00" + str(i) + ".png"
        #             else:
        #                 name = fname + "0" + str(i) + ".png"
        #         else:
        #             name = fname + str(i) + ".png"
        im = Image.open(name).load() #Can be many different formats.
                # pixels = []
                # for k in range(1024):
                #     for j in range(1024):
                #         pixels.append(im[k,j])
        # center = random.randrange(482,542)
        if num_img_to_display < 32 :
            img = Image.open(name).convert("L")
            data_con.append(img)
            ++num_img_to_display
            
        pixels = [im[k,j]/256.0 for k in range(0, IMG_WIDTH) for j in range(0, IMG_WIDTH)]
        mgrams.append(pixels)
    print("Total images: ", len(mgrams))
    # print("Total pixels: ", len(mgrams[0]))
    print("Total labels: ", len(labels))
    print("Normals: ", n, "Benign: ", b, "Malignant: ", m)
    
    # plot images from the training dataset
    for i in np.arange(0, int(len(data_con)/8)):
        pyplot.subplot(1, 1, 1) 
        pyplot.axis('on')
        img= np.asarray(data_con[i])
        pyplot.imshow(img, cmap='gray') # plot raw pixel data
        
    pyplot.grid(b=None)
    pyplot.axis('off')
    pyplot.show()
    
    '''
    
    RESIZE_IMG_WIDTH=64 #32, 299 1024  2560  
    RESIZE_IMG_HEIGHT=64
    # plot images from the training dataset
    for i in np.arange(0, int(len(data_con)/8)):
        pyplot.subplot(1, 1, 1) 
        pyplot.axis('on')
        img= np.asarray(data_con[i])
        img = resizeimage.resize_cover(img, [RESIZE_IMG_WIDTH, RESIZE_IMG_HEIGHT])
        pyplot.imshow(img, cmap='gray') # plot raw pixel data
        
    pyplot.grid(b=None)
    pyplot.axis('off')
    pyplot.show()
    '''
    return mdata(mgrams, labels, n, b, m, ad, asy, ms, calc)



    # mgrams = np.ndarray(shape=(num_images - 1,48*48), buffer=np.array(mgrams), dtype=float32)

    #read label data
    #https://www.tensorflow.org/versions/r0.7/tutorials/mnist/beginners/index.html#mnist-for-ml-beginners

    # del labels[num_images:]
